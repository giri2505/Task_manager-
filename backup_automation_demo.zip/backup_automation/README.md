# Backup Failure Automation – Demo Guide

## What This Automation Does

When a backup failure ticket comes in, this script automatically:

1. **Checks server reachability** — pings the server to confirm it's online
2. **Identifies the OS** — looks up the server in the Linux or Windows inventory file
3. **Checks services** (via SSH / WinRM):
   - **Linux**: veeam-transport, ssh, rsyslog, crond
   - **Windows**: VSS, SW Shadow Copy Provider, Backup Engine, CryptSvc
4. **Restarts failed services** automatically
5. **Checks storage**:
   - **Linux**: runs `df -h`, flags partitions above 85% usage
   - **Windows**: checks VSS writers, ASR writer, shadow copy storage
6. **Generates a remediation report** and saves it as a text file

---

## File Structure

```
backup_automation/
├── backup_remediation.py   # Main automation script
├── run_demo.py             # Demo runner (shows both Linux & Windows)
├── linux_inventory.csv     # Linux server inventory (IP + hostname)
├── windows_inventory.csv   # Windows server inventory (IP + hostname)
└── README.md               # This file
```

---

## Demo Steps (for your manager)

### Option A – Run the full demo (both Linux + Windows)
```bash
python3 run_demo.py
```
This shows two complete scenarios back-to-back:
- Windows server: detects a stopped Shadow Copy Provider service, restarts it, and flags a failed ASR writer
- Linux server: detects veeam-transport is stopped, restarts it, flags disk space at 95%

### Option B – Run a single scenario
```bash
# Windows server simulation
python3 backup_remediation.py --demo --server win-backup-01 --ticket INC0001001

# Linux server simulation
python3 backup_remediation.py --demo --server backup-srv-01 --ticket INC0001002
```

### Option C – Target a real server (live environment)
```bash
# Requires SSH key access to Linux servers, WinRM configured for Windows
python3 backup_remediation.py --server <hostname_or_ip> --ticket INC0001234
```

---

## Inventory Files

### linux_inventory.csv
| hostname | ip_address | os | environment |
|---|---|---|---|
| web-server-01 | 192.168.1.10 | linux | production |
| db-server-01 | 192.168.1.11 | linux | production |
| app-server-01 | 192.168.1.12 | linux | staging |
| backup-srv-01 | 192.168.1.13 | linux | production |

### windows_inventory.csv
| hostname | ip_address | os | environment |
|---|---|---|---|
| win-file-srv01 | 192.168.1.20 | windows | production |
| win-app-srv01 | 192.168.1.21 | windows | production |
| win-db-srv01 | 192.168.1.22 | windows | staging |
| win-backup-01 | 192.168.1.23 | windows | production |

---

## What the Demo Shows Your Manager

| Step | What the script does | Output |
|---|---|---|
| Ticket received | Script takes ticket ID + server name | Banner with ticket details |
| Reachability | Simulates ping to server IP | "reachable – 4/4 packets" |
| Inventory lookup | Finds server OS from CSV | "Windows / Linux confirmed" |
| Service check | Checks each backup service | Green OK or Yellow WARN |
| Auto-restart | Restarts any stopped service | "Successfully restarted" |
| Disk / VSS check | df -h or vssadmin output | Highlights critical issues |
| Report | Saves ticket remediation report | Text file with all actions |

---

## Production Enhancements (next steps after demo)

- **ServiceNow / Jira integration**: auto-update the ticket with the report
- **Email/Slack alert**: notify on-call team if manual action is needed
- **Credential management**: use HashiCorp Vault or AWS Secrets Manager for SSH/WinRM creds
- **Parallelism**: use `ThreadPoolExecutor` to check multiple servers simultaneously
- **Retry logic**: retry service restarts up to 3 times before escalating
