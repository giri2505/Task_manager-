#!/usr/bin/env python3
"""
Backup Failure Automation Script
=================================
Automates the response to backup failure tickets:
  1. Check server reachability
  2. Identify OS from inventory (Linux/Windows)
  3. SSH into server and check/restart services
  4. Check disk space (Linux) or VSS/writers (Windows)
  5. Generate a remediation report

Run modes:
  --demo    : Simulate all steps without real SSH (safe for demos)
  --server  : Provide hostname/IP for a real server
"""

import argparse
import csv
import os
import time
import subprocess
import platform
from datetime import datetime

# ── Colour helpers ────────────────────────────────────────────────────────────
GREEN  = "\033[92m"
YELLOW = "\033[93m"
RED    = "\033[91m"
CYAN   = "\033[96m"
BOLD   = "\033[1m"
RESET  = "\033[0m"

def banner(text):
    print(f"\n{BOLD}{CYAN}{'='*60}{RESET}")
    print(f"{BOLD}{CYAN}  {text}{RESET}")
    print(f"{BOLD}{CYAN}{'='*60}{RESET}")

def step(msg):
    print(f"\n{BOLD}[STEP]{RESET} {msg}")

def ok(msg):
    print(f"  {GREEN}[OK]{RESET}    {msg}")

def warn(msg):
    print(f"  {YELLOW}[WARN]{RESET}  {msg}")

def fail(msg):
    print(f"  {RED}[FAIL]{RESET}  {msg}")

def info(msg):
    print(f"  {CYAN}[INFO]{RESET}  {msg}")

# ── Inventory lookup ──────────────────────────────────────────────────────────
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

def load_inventory():
    """Load Linux and Windows inventory files into a single dict keyed by hostname/IP."""
    inventory = {}
    for fname in ("linux_inventory.csv", "windows_inventory.csv"):
        fpath = os.path.join(SCRIPT_DIR, fname)
        if not os.path.exists(fpath):
            warn(f"Inventory file not found: {fpath}")
            continue
        with open(fpath, newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                inventory[row["hostname"].lower()] = row
                inventory[row["ip_address"]]       = row
    return inventory

def lookup_server(identifier, inventory):
    return inventory.get(identifier.lower())

# ── Reachability check ────────────────────────────────────────────────────────
def check_reachability(ip, demo=False):
    step(f"Checking reachability of {ip} ...")
    if demo:
        time.sleep(0.8)
        ok(f"{ip} is reachable (simulated ping: 4/4 packets received)")
        return True
    # Real ping
    param = "-n" if platform.system().lower() == "windows" else "-c"
    result = subprocess.run(
        ["ping", param, "4", ip],
        capture_output=True, text=True, timeout=15
    )
    if result.returncode == 0:
        ok(f"{ip} is reachable")
        return True
    else:
        fail(f"{ip} is NOT reachable. Escalating ticket.")
        return False

# ── Linux checks ─────────────────────────────────────────────────────────────
LINUX_SERVICES = [
    "veeam-transport",   # Veeam backup agent
    "ssh",               # Remote access
    "rsyslog",           # Logging
    "crond",             # Scheduler (backup jobs)
]

SIMULATED_LINUX_STATUS = {
    "veeam-transport": "inactive",   # <-- will trigger restart demo
    "ssh":             "active",
    "rsyslog":         "active",
    "crond":           "active",
}

SIMULATED_DF = """
Filesystem      Size  Used Avail Use% Mounted on
/dev/sda1        50G   38G   12G  76% /
/dev/sdb1       200G  190G   10G  95% /backup    <-- WARNING: 95% full!
tmpfs           3.9G     0  3.9G   0% /dev/shm
"""

def check_linux_services(hostname, ip, demo=False):
    banner("LINUX SERVER CHECKS")
    report = {"services": {}, "disk": "", "actions": []}

    step("Checking backup-related services ...")
    for svc in LINUX_SERVICES:
        if demo:
            time.sleep(0.3)
            status = SIMULATED_LINUX_STATUS.get(svc, "active")
        else:
            # Real SSH command (requires paramiko or key-based SSH setup)
            status = _ssh_service_status(ip, svc)

        report["services"][svc] = status
        if status == "active":
            ok(f"{svc:<25} active (running)")
        else:
            warn(f"{svc:<25} {status} — attempting restart ...")
            restarted = restart_linux_service(ip, svc, demo)
            if restarted:
                report["services"][svc] = "restarted"
                report["actions"].append(f"Restarted service: {svc}")
                ok(f"{svc:<25} successfully restarted")
            else:
                fail(f"{svc:<25} FAILED to restart — manual intervention needed")
                report["actions"].append(f"FAILED to restart: {svc}")

    step("Checking disk space (df -h) ...")
    if demo:
        time.sleep(0.4)
        report["disk"] = SIMULATED_DF
        print(SIMULATED_DF)
        warn("Backup partition /dev/sdb1 is at 95% — cleanup recommended!")
        report["actions"].append("ALERT: /backup partition at 95% — disk cleanup required")
    else:
        output = _ssh_run(ip, "df -h")
        report["disk"] = output
        print(output)
        _analyze_df(output, report)

    return report

def restart_linux_service(ip, service, demo=False):
    if demo:
        time.sleep(0.5)
        return True
    return _ssh_run(ip, f"sudo systemctl restart {service}") is not None

def _ssh_service_status(ip, service):
    """Real SSH service status check — requires key-based SSH or paramiko."""
    output = _ssh_run(ip, f"systemctl is-active {service}")
    return (output or "unknown").strip()

def _ssh_run(ip, command, user="root"):
    """Execute a command on a remote host via SSH (key-based auth)."""
    try:
        result = subprocess.run(
            ["ssh", "-o", "StrictHostKeyChecking=no", f"{user}@{ip}", command],
            capture_output=True, text=True, timeout=30
        )
        return result.stdout.strip() if result.returncode == 0 else None
    except Exception as e:
        fail(f"SSH error: {e}")
        return None

def _analyze_df(df_output, report):
    for line in df_output.splitlines():
        parts = line.split()
        if len(parts) >= 5:
            try:
                pct = int(parts[4].replace("%", ""))
                if pct >= 85:
                    warn(f"Disk {parts[5]} at {pct}% — action required!")
                    report["actions"].append(f"ALERT: Disk {parts[5]} at {pct}%")
            except (ValueError, IndexError):
                pass

# ── Windows checks ────────────────────────────────────────────────────────────
WINDOWS_SERVICES = [
    ("VSS",              "Volume Shadow Copy"),
    ("swprv",            "MS Software Shadow Copy Provider"),
    ("wbengine",         "Windows Backup Engine"),
    ("CryptSvc",         "Cryptographic Services"),
    ("EventSystem",      "COM+ Event System"),
]

SIMULATED_WIN_STATUS = {
    "VSS":         "Running",
    "swprv":       "Stopped",   # <-- will trigger restart demo
    "wbengine":    "Running",
    "CryptSvc":    "Running",
    "EventSystem": "Running",
}

SIMULATED_VSS_WRITERS = """
Writer name: 'System Writer'         State: [1] Stable    Last error: No error
Writer name: 'COM+ REGDB Writer'     State: [1] Stable    Last error: No error
Writer name: 'WMI Writer'            State: [1] Stable    Last error: No error
Writer name: 'Registry Writer'       State: [1] Stable    Last error: No error
Writer name: 'ASR Writer'            State: [8] Failed    Last error: Retryable error  <-- ISSUE
Writer name: 'NTDS'                  State: [1] Stable    Last error: No error
Writer name: 'Shadow Copy Opt. Writ' State: [1] Stable    Last error: No error
"""

def check_windows_services(hostname, ip, demo=False):
    banner("WINDOWS SERVER CHECKS")
    report = {"services": {}, "vss_writers": "", "actions": []}

    step("Checking backup-related Windows services ...")
    for svc_name, svc_display in WINDOWS_SERVICES:
        if demo:
            time.sleep(0.3)
            status = SIMULATED_WIN_STATUS.get(svc_name, "Running")
        else:
            status = _winrm_service_status(ip, svc_name)

        report["services"][svc_name] = status
        if status == "Running":
            ok(f"{svc_display:<40} Running")
        else:
            warn(f"{svc_display:<40} {status} — attempting restart ...")
            restarted = restart_windows_service(ip, svc_name, demo)
            if restarted:
                report["services"][svc_name] = "Restarted"
                report["actions"].append(f"Restarted service: {svc_display}")
                ok(f"{svc_display:<40} successfully restarted")
            else:
                fail(f"{svc_display:<40} FAILED to restart")
                report["actions"].append(f"FAILED to restart: {svc_display}")

    step("Checking VSS writers and ASR writer status ...")
    if demo:
        time.sleep(0.4)
        report["vss_writers"] = SIMULATED_VSS_WRITERS
        print(SIMULATED_VSS_WRITERS)
        warn("ASR Writer is in FAILED state — this blocks system-state backups!")
        report["actions"].append("ALERT: ASR Writer in Failed state — run 'vssadmin list writers' on server to investigate")
    else:
        output = _winrm_run(ip, "vssadmin list writers")
        report["vss_writers"] = output
        print(output)
        _analyze_vss(output, report)

    step("Checking Volume Shadow Copy storage ...")
    if demo:
        time.sleep(0.3)
        vsc = """
  Shadow Copy Storage association
    For volume: (C:)\\\\?\\Volume{abc123}\\
    Shadow Copy Storage volume: (C:)\\\\?\\Volume{abc123}\\
    Used Shadow Copy Storage space: 3.50 GB (3%)
    Allocated Shadow Copy Storage space: 4.00 GB (4%)
    Maximum Shadow Copy Storage space: UNBOUNDED
        """
        print(vsc)
        ok("Volume Shadow Copy storage looks healthy")
    else:
        output = _winrm_run(ip, "vssadmin list shadowstorage")
        print(output)

    return report

def restart_windows_service(ip, service, demo=False):
    if demo:
        time.sleep(0.5)
        return True
    return _winrm_run(ip, f"Restart-Service -Name {service} -Force") is not None

def _winrm_service_status(ip, service):
    """Real WinRM service check (requires winrm/pywinrm configured)."""
    try:
        import winrm
        session = winrm.Protocol(f"http://{ip}:5985/wsman", transport="ntlm",
                                 username="Administrator", password="YourPassword")
        shell_id = session.open_shell()
        command_id = session.run_command(shell_id, f"sc query {service}")
        stdout, _, _ = session.get_command_output(shell_id, command_id)
        session.cleanup_command(shell_id, command_id)
        session.close_shell(shell_id)
        return "Running" if b"RUNNING" in stdout else "Stopped"
    except Exception as e:
        fail(f"WinRM error: {e}")
        return "Unknown"

def _winrm_run(ip, command):
    fail("Real WinRM execution not configured — use --demo flag for demo mode")
    return None

def _analyze_vss(vss_output, report):
    for line in vss_output.splitlines():
        if "Failed" in line or "failed" in line:
            warn(f"VSS writer issue detected: {line.strip()}")
            report["actions"].append(f"VSS Writer issue: {line.strip()}")

# ── Report generator ──────────────────────────────────────────────────────────
def generate_report(ticket_id, hostname, ip, os_type, report):
    banner("REMEDIATION REPORT")
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    lines = [
        "=" * 60,
        f"  BACKUP FAILURE REMEDIATION REPORT",
        "=" * 60,
        f"  Ticket ID   : {ticket_id}",
        f"  Hostname    : {hostname}",
        f"  IP Address  : {ip}",
        f"  OS Type     : {os_type}",
        f"  Timestamp   : {ts}",
        "=" * 60,
        "",
        "SERVICE STATUS:",
    ]
    for svc, status in report.get("services", {}).items():
        flag = "OK" if status in ("active", "Running") else "ACTION TAKEN" if "restart" in status.lower() else "FAILED"
        lines.append(f"  [{flag:^11}] {svc} — {status}")

    if report.get("actions"):
        lines += ["", "ACTIONS TAKEN / ALERTS:"]
        for action in report["actions"]:
            prefix = "ALERT" if "ALERT" in action or "FAILED" in action else "ACTION"
            lines.append(f"  [{prefix}] {action}")

    lines += [
        "",
        "RECOMMENDATION:",
        "  Review the alerts above and confirm backup runs successfully.",
        "  If issues persist, escalate to the backup team.",
        "=" * 60,
    ]

    report_text = "\n".join(lines)
    print(report_text)

    report_file = os.path.join(SCRIPT_DIR, f"report_{ticket_id}_{hostname}.txt")
    with open(report_file, "w") as f:
        f.write(report_text)
    ok(f"Report saved to: {report_file}")
    return report_file

# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="Backup Failure Automation Script")
    parser.add_argument("--ticket",   default="INC0012345", help="Ticket/incident ID")
    parser.add_argument("--server",   default=None,         help="Hostname or IP to remediate")
    parser.add_argument("--demo",     action="store_true",  help="Run in simulation/demo mode")
    args = parser.parse_args()

    banner("BACKUP FAILURE AUTOMATION STARTING")

    if args.demo:
        info("Running in DEMO mode — no real SSH connections will be made")

    # Load inventory
    step("Loading server inventory ...")
    inventory = load_inventory()
    ok(f"Loaded {len(set(v['hostname'] for v in inventory.values()))} servers from inventory")

    # Determine which server to check
    if args.demo and not args.server:
        # Pick a default demo server
        args.server = "win-backup-01"
        info(f"Demo mode: using server '{args.server}'")

    if not args.server:
        fail("Please specify --server <hostname_or_ip> or use --demo")
        return

    server_info = lookup_server(args.server, inventory)
    if not server_info:
        fail(f"Server '{args.server}' not found in inventory. Check inventory files.")
        return

    hostname = server_info["hostname"]
    ip       = server_info["ip_address"]
    os_type  = server_info["os"].lower()
    env      = server_info.get("environment", "unknown")

    info(f"Server found: {hostname} | IP: {ip} | OS: {os_type.upper()} | Env: {env}")

    # Step 1: Reachability
    if not check_reachability(ip, demo=args.demo):
        fail("Server unreachable — creating escalation note and exiting.")
        return

    # Step 2 & 3: OS-specific checks
    if os_type == "linux":
        report = check_linux_services(hostname, ip, demo=args.demo)
    elif os_type == "windows":
        report = check_windows_services(hostname, ip, demo=args.demo)
    else:
        fail(f"Unknown OS type '{os_type}' in inventory. Cannot proceed.")
        return

    # Step 4: Report
    generate_report(args.ticket, hostname, ip, os_type, report)
    banner("AUTOMATION COMPLETE")

if __name__ == "__main__":
    main()
