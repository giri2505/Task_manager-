#!/usr/bin/env python3
"""
Demo runner — shows the full automation for both a Linux and a Windows server.
Run this file directly:  python3 run_demo.py
"""
import subprocess
import sys
import os

SCRIPT = os.path.join(os.path.dirname(__file__), "backup_remediation.py")

def run(label, server, ticket):
    print(f"\n\033[1m\033[96m{'#'*60}\033[0m")
    print(f"\033[1m\033[96m  DEMO: {label}\033[0m")
    print(f"\033[1m\033[96m{'#'*60}\033[0m")
    subprocess.run(
        [sys.executable, SCRIPT, "--demo", "--server", server, "--ticket", ticket],
        check=False
    )

if __name__ == "__main__":
    # Demo 1: Windows server (shows VSS/ASR/Crypto checks)
    run("Windows Backup Failure", "win-backup-01", "INC0001001")
    # Demo 2: Linux server (shows service + df -h checks)
    run("Linux Backup Failure",   "backup-srv-01", "INC0001002")
    print("\n\033[92m\033[1mAll demos complete!\033[0m\n")
