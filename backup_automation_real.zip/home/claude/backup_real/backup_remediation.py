#!/usr/bin/env python3
"""
Backup Failure Automation Script — REAL MODE
=============================================
Runs from a Linux jump server.
Connects to Linux AND Windows servers via SSH (paramiko, username+password).
Windows servers must have OpenSSH installed and running.

Usage:
    python3 backup_remediation.py --ticket INC0001234 --server web-server-01
    python3 backup_remediation.py --ticket INC0001234 --server 192.168.1.10

Requirements:
    pip install paramiko
"""

import argparse
import csv
import getpass
import os
import sys
import time
from datetime import datetime

import paramiko

# ── Colour helpers ────────────────────────────────────────────────────────────
GREEN  = "\033[92m"
YELLOW = "\033[93m"
RED    = "\033[91m"
CYAN   = "\033[96m"
BOLD   = "\033[1m"
RESET  = "\033[0m"

def banner(text):
    print(f"\n{BOLD}{CYAN}{'='*60}{RESET}")
    print(f"{BOLD}{CYAN}  {text}{RESET}")
    print(f"{BOLD}{CYAN}{'='*60}{RESET}")

def step(msg):   print(f"\n{BOLD}[STEP]{RESET} {msg}")
def ok(msg):     print(f"  {GREEN}[OK]{RESET}    {msg}")
def warn(msg):   print(f"  {YELLOW}[WARN]{RESET}  {msg}")
def fail(msg):   print(f"  {RED}[FAIL]{RESET}  {msg}")
def info(msg):   print(f"  {CYAN}[INFO]{RESET}  {msg}")

# ── Inventory ─────────────────────────────────────────────────────────────────
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

def load_inventory():
    inventory = {}
    for fname in ("linux_inventory.csv", "windows_inventory.csv"):
        fpath = os.path.join(SCRIPT_DIR, fname)
        if not os.path.exists(fpath):
            warn(f"Inventory file missing: {fpath}")
            continue
        with open(fpath, newline="") as f:
            for row in csv.DictReader(f):
                inventory[row["hostname"].lower()] = row
                inventory[row["ip_address"]]       = row
        ok(f"Loaded {fname}")
    return inventory

# ── SSH connection (paramiko) ─────────────────────────────────────────────────
def ssh_connect(ip, username, password, port=22, timeout=15):
    """Open an SSH connection. Returns (client, None) or (None, error_message)."""
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(
            hostname=ip,
            port=port,
            username=username,
            password=password,
            timeout=timeout,
            look_for_keys=False,
            allow_agent=False,
        )
        return client, None
    except paramiko.AuthenticationException:
        return None, "Authentication failed — check username/password"
    except paramiko.ssh_exception.NoValidConnectionsError:
        return None, f"Cannot connect to {ip}:{port} — is SSH running?"
    except Exception as e:
        return None, str(e)

def ssh_run(client, command, timeout=30):
    """Run a command over an existing SSH connection. Returns (stdout, stderr, exit_code)."""
    try:
        _, stdout, stderr = client.exec_command(command, timeout=timeout)
        exit_code = stdout.channel.recv_exit_status()
        return stdout.read().decode(errors="replace").strip(), \
               stderr.read().decode(errors="replace").strip(), \
               exit_code
    except Exception as e:
        return "", str(e), -1

# ── Reachability ──────────────────────────────────────────────────────────────
def check_reachability(ip, username, password, port=22):
    step(f"Checking reachability of {ip} (SSH port {port}) ...")
    client, err = ssh_connect(ip, username, password, port=port, timeout=10)
    if client:
        out, _, _ = ssh_run(client, "echo reachable")
        client.close()
        if "reachable" in out:
            ok(f"{ip} is reachable and SSH is responding")
            return True
    fail(f"{ip} is NOT reachable: {err}")
    return False

# ── Linux checks ──────────────────────────────────────────────────────────────
LINUX_SERVICES = [
    "veeam-transport",
    "ssh",
    "rsyslog",
    "cron",
]

DISK_WARN_PCT = 85

def check_linux(ip, username, password, report):
    step("Connecting to Linux server ...")
    client, err = ssh_connect(ip, username, password)
    if not client:
        fail(f"SSH connection failed: {err}")
        report["connection_error"] = err
        return

    ok(f"SSH connected to {ip}")

    # ── Services ──
    step("Checking backup-related services ...")
    for svc in LINUX_SERVICES:
        out, _, rc = ssh_run(client, f"systemctl is-active {svc} 2>/dev/null || service {svc} status 2>/dev/null | grep -c running")
        status = out.strip() if out.strip() else "unknown"
        report["services"][svc] = status

        if status == "active" or status == "1":
            ok(f"  {svc:<28} active")
        else:
            warn(f"  {svc:<28} {status} — restarting ...")
            _, err_out, rc2 = ssh_run(client, f"sudo systemctl restart {svc} 2>&1 || sudo service {svc} restart 2>&1")
            time.sleep(2)
            # Verify
            out2, _, _ = ssh_run(client, f"systemctl is-active {svc} 2>/dev/null")
            new_status = out2.strip()
            if new_status == "active":
                ok(f"  {svc:<28} restarted successfully")
                report["services"][svc] = "restarted → active"
                report["actions"].append(f"Restarted service: {svc}")
            else:
                fail(f"  {svc:<28} restart FAILED (status: {new_status})")
                report["services"][svc] = f"restart failed ({new_status})"
                report["actions"].append(f"FAILED to restart: {svc} — manual action needed")

    # ── Disk space ──
    step("Checking disk space (df -h) ...")
    df_out, _, _ = ssh_run(client, "df -h")
    report["disk"] = df_out
    print(f"\n{df_out}\n")

    for line in df_out.splitlines()[1:]:          # skip header
        parts = line.split()
        if len(parts) >= 5:
            try:
                pct = int(parts[4].replace("%", ""))
                mount = parts[5] if len(parts) > 5 else parts[4]
                if pct >= DISK_WARN_PCT:
                    warn(f"Disk {mount} is at {pct}% — cleanup recommended!")
                    report["actions"].append(f"ALERT: {mount} disk at {pct}% — cleanup required")
                else:
                    ok(f"Disk {mount} at {pct}% — OK")
            except (ValueError, IndexError):
                pass

    client.close()
    info("SSH session closed")

# ── Windows checks ────────────────────────────────────────────────────────────
WINDOWS_SERVICES = [
    ("VSS",         "Volume Shadow Copy"),
    ("swprv",       "MS Software Shadow Copy Provider"),
    ("wbengine",    "Windows Backup Engine"),
    ("CryptSvc",    "Cryptographic Services"),
    ("EventSystem", "COM+ Event System"),
]

def check_windows(ip, username, password, report):
    step("Connecting to Windows server via SSH (OpenSSH) ...")
    client, err = ssh_connect(ip, username, password, port=22)
    if not client:
        fail(f"SSH connection failed: {err}")
        report["connection_error"] = err
        return

    ok(f"SSH connected to {ip}")

    # ── Services ──
    step("Checking backup-related Windows services ...")
    for svc_name, svc_display in WINDOWS_SERVICES:
        # PowerShell via SSH on Windows
        cmd = f'powershell -Command "(Get-Service -Name {svc_name}).Status"'
        out, _, _ = ssh_run(client, cmd)
        status = out.strip()
        report["services"][svc_name] = status

        if status.lower() == "running":
            ok(f"  {svc_display:<40} Running")
        else:
            warn(f"  {svc_display:<40} {status if status else 'Unknown'} — restarting ...")
            restart_cmd = f'powershell -Command "Start-Service -Name {svc_name}"'
            _, err_out, rc = ssh_run(client, restart_cmd)
            time.sleep(2)
            # Verify
            out2, _, _ = ssh_run(client, cmd)
            new_status = out2.strip()
            if new_status.lower() == "running":
                ok(f"  {svc_display:<40} restarted successfully")
                report["services"][svc_name] = "Restarted → Running"
                report["actions"].append(f"Restarted service: {svc_display}")
            else:
                fail(f"  {svc_display:<40} restart FAILED ({new_status})")
                report["services"][svc_name] = f"Restart failed ({new_status})"
                report["actions"].append(f"FAILED to restart: {svc_display}")

    # ── VSS Writers ──
    step("Checking VSS writers (vssadmin list writers) ...")
    vss_cmd = 'powershell -Command "vssadmin list writers"'
    vss_out, _, _ = ssh_run(client, vss_cmd)
    report["vss_writers"] = vss_out
    print(f"\n{vss_out}\n")

    failed_writers = []
    current_writer = ""
    for line in vss_out.splitlines():
        if "Writer name:" in line:
            current_writer = line.split("Writer name:")[-1].strip().strip("'")
        if "State:" in line and ("Failed" in line or "failed" in line):
            warn(f"VSS Writer FAILED: {current_writer} — {line.strip()}")
            report["actions"].append(f"ALERT: VSS Writer '{current_writer}' in failed state")
            failed_writers.append(current_writer)

    if not failed_writers:
        ok("All VSS writers are stable")

    # ── Shadow Copy Storage ──
    step("Checking Volume Shadow Copy storage ...")
    vsc_cmd = 'powershell -Command "vssadmin list shadowstorage"'
    vsc_out, _, _ = ssh_run(client, vsc_cmd)
    print(f"\n{vsc_out}\n")
    report["shadow_storage"] = vsc_out

    # Parse used % if present
    for line in vsc_out.splitlines():
        if "Used Shadow Copy" in line and "%" in line:
            try:
                pct_str = line.split("(")[-1].replace(")", "").replace("%", "").strip()
                pct = int(float(pct_str))
                if pct >= 80:
                    warn(f"Shadow Copy Storage at {pct}% — consider increasing allocation")
                    report["actions"].append(f"ALERT: Shadow Copy Storage at {pct}%")
                else:
                    ok(f"Shadow Copy Storage at {pct}% — OK")
            except (ValueError, IndexError):
                pass

    client.close()
    info("SSH session closed")

# ── Report ────────────────────────────────────────────────────────────────────
def generate_report(ticket_id, hostname, ip, os_type, report):
    banner("REMEDIATION REPORT")
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    lines = [
        "=" * 60,
        "  BACKUP FAILURE REMEDIATION REPORT",
        "=" * 60,
        f"  Ticket ID   : {ticket_id}",
        f"  Hostname    : {hostname}",
        f"  IP Address  : {ip}",
        f"  OS Type     : {os_type.upper()}",
        f"  Timestamp   : {ts}",
        "=" * 60,
        "",
    ]

    if report.get("connection_error"):
        lines += [
            "CONNECTION ERROR:",
            f"  {report['connection_error']}",
            "",
            "RECOMMENDATION:",
            "  Verify SSH is running on the target server.",
            "  Confirm credentials and network access from jump server.",
        ]
    else:
        lines += ["SERVICE STATUS:"]
        for svc, status in report.get("services", {}).items():
            s = status.lower()
            if "active" in s or "running" in s:
                tag = "OK"
            elif "restart" in s:
                tag = "RESTARTED"
            else:
                tag = "FAILED"
            lines.append(f"  [{tag:^10}] {svc} — {status}")

        if report.get("actions"):
            lines += ["", "ACTIONS TAKEN / ALERTS:"]
            for action in report["actions"]:
                tag = "ALERT" if "ALERT" in action or "FAILED" in action else "ACTION"
                lines.append(f"  [{tag}] {action}")

        lines += [
            "",
            "RECOMMENDATION:",
            "  Review alerts above. Re-trigger backup job and confirm success.",
            "  If issues persist, escalate to the backup engineering team.",
        ]

    lines.append("=" * 60)
    report_text = "\n".join(lines)
    print(report_text)

    report_file = os.path.join(SCRIPT_DIR, f"report_{ticket_id}_{hostname}.txt")
    with open(report_file, "w") as f:
        f.write(report_text)
    ok(f"Report saved → {report_file}")

# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="Backup Failure Automation (Real Mode)")
    parser.add_argument("--ticket",   required=True, help="Incident/ticket ID e.g. INC0001234")
    parser.add_argument("--server",   required=True, help="Hostname or IP address of the affected server")
    parser.add_argument("--username", default=None,  help="SSH username (prompted if not provided)")
    parser.add_argument("--password", default=None,  help="SSH password (prompted if not provided — recommended)")
    parser.add_argument("--port",     default=22, type=int, help="SSH port (default: 22)")
    args = parser.parse_args()

    banner("BACKUP FAILURE AUTOMATION — REAL MODE")
    info(f"Ticket  : {args.ticket}")
    info(f"Server  : {args.server}")
    info(f"Started : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    # Load inventory
    step("Loading server inventory ...")
    inventory = load_inventory()
    total = len(set(v["hostname"] for v in inventory.values()))
    ok(f"Loaded {total} servers from inventory")

    server_info = inventory.get(args.server.lower()) or inventory.get(args.server)
    if not server_info:
        fail(f"'{args.server}' not found in inventory. Check linux_inventory.csv / windows_inventory.csv.")
        sys.exit(1)

    hostname = server_info["hostname"]
    ip       = server_info["ip_address"]
    os_type  = server_info["os"].lower()
    env      = server_info.get("environment", "unknown")

    info(f"Inventory match: {hostname} | IP: {ip} | OS: {os_type.upper()} | Env: {env}")

    # Credentials
    username = args.username or input(f"\nSSH username for {hostname}: ").strip()
    password = args.password or getpass.getpass(f"SSH password for {username}@{hostname}: ")

    # Reachability
    if not check_reachability(ip, username, password, port=args.port):
        fail("Server unreachable. Verify network path from jump server.")
        sys.exit(1)

    report = {"services": {}, "actions": []}

    # OS-specific checks
    if os_type == "linux":
        check_linux(ip, username, password, report)
    elif os_type == "windows":
        check_windows(ip, username, password, report)
    else:
        fail(f"Unknown OS type '{os_type}' in inventory.")
        sys.exit(1)

    generate_report(args.ticket, hostname, ip, os_type, report)
    banner("AUTOMATION COMPLETE")

if __name__ == "__main__":
    main()
