# Backup Failure Automation — Real Mode

## Prerequisites

### On the Linux jump server (where you run this script)
```bash
pip3 install -r requirements.txt
```

### On each Linux target server
- SSH must be running (port 22)
- The SSH user must have sudo rights to run `systemctl restart`
- Add this to `/etc/sudoers` (replace `backupuser` with your username):
  ```
  backupuser ALL=(ALL) NOPASSWD: /bin/systemctl restart *
  ```

### On each Windows target server
- OpenSSH must be installed and running:
  ```powershell
  # Run as Administrator on the Windows server
  Add-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0
  Start-Service sshd
  Set-Service -Name sshd -StartupType Automatic
  ```
- The SSH user must be a local Administrator or have rights to run `Start-Service`

---

## Update Inventory Files

Edit `linux_inventory.csv` and `windows_inventory.csv` with your actual servers:

```
hostname,ip_address,os,environment
your-server-01,10.0.0.5,linux,production
your-win-srv,10.0.0.10,windows,production
```

---

## Running the Script

```bash
# Basic usage (will prompt for username and password)
python3 backup_remediation.py --ticket INC0001234 --server web-server-01

# Pass username on command line (password will still be prompted securely)
python3 backup_remediation.py --ticket INC0001234 --server web-server-01 --username backupuser

# If SSH is on a non-standard port
python3 backup_remediation.py --ticket INC0001234 --server win-backup-01 --port 2222
```

---

## What the Script Does

| Step | Action |
|------|--------|
| 1 | Looks up server in inventory to determine OS |
| 2 | Opens SSH connection and confirms reachability |
| 3 | **Linux**: checks `veeam-transport`, `ssh`, `rsyslog`, `cron` via `systemctl` |
| 3 | **Windows**: checks VSS, Shadow Copy Provider, Backup Engine, CryptSvc via PowerShell |
| 4 | Auto-restarts any stopped/failed service and verifies it came back up |
| 5 | **Linux**: runs `df -h` and alerts on any partition above 85% |
| 5 | **Windows**: runs `vssadmin list writers` and `vssadmin list shadowstorage` |
| 6 | Saves a full remediation report as `report_<TICKET>_<HOSTNAME>.txt` |

---

## Adding More Services to Monitor

**Linux** — edit `LINUX_SERVICES` list in the script:
```python
LINUX_SERVICES = [
    "veeam-transport",
    "ssh",
    "rsyslog",
    "cron",
    "your-custom-service",   # <-- add here
]
```

**Windows** — edit `WINDOWS_SERVICES` list:
```python
WINDOWS_SERVICES = [
    ("VSS",      "Volume Shadow Copy"),
    ("YourSvc",  "Your Service Display Name"),  # <-- add here
]
```

---

## Disk Alert Threshold

Default alert threshold is **85%**. Change this at the top of the script:
```python
DISK_WARN_PCT = 85
```
