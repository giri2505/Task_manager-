"""
AI Analysis Module — NetWorker Remediation Intelligence Layer
=============================================================
Supports two AI providers — whichever is configured in dashboard_config.json:

  ── AZURE AI FOUNDRY (primary) ───────────────────────────────────────────────
  Azure AI Foundry deployments expose an OpenAI-compatible REST endpoint.
  Required settings (all in dashboard_config.json / Settings tab):
    azure_endpoint    https://<your-resource>.openai.azure.com/
                      OR the full inference URL from Azure AI Foundry:
                      https://<project>.inference.ml.azure.com/
    azure_deployment  Your model deployment name  (e.g. gpt-4o, Phi-4, Mistral-Large-2407)
    azure_api_key     Your Azure AI API key
    azure_api_version API version string (default: 2024-08-01-preview)

  URL patterns handled automatically:
    *.openai.azure.com      →  /openai/deployments/{deployment}/chat/completions?api-version=...
    *.inference.ml.azure.com →  /v1/chat/completions   (Foundry managed compute / MaaS)
    *.inference.ai.azure.com →  /v1/chat/completions   (Foundry serverless)

  ── ANTHROPIC CLAUDE (fallback) ──────────────────────────────────────────────
  If Azure is not configured, falls back to Anthropic if anthropic_api_key is set.

  ── GRACEFUL NO-OP ────────────────────────────────────────────────────────────
  If neither provider is configured all AI functions return the ticket unchanged.
"""

import json
import os
import re
import urllib.request
import urllib.error
from datetime import datetime
from typing import Optional

# Runtime config — injected by dashboard_api.py via configure()
_cfg: dict = {}

def configure(cfg: dict):
    """Inject config from dashboard_config.json into this module."""
    global _cfg
    _cfg = cfg or {}

# ── Provider detection ────────────────────────────────────────────────────────

def _azure_ready() -> bool:
    return bool(
        _cfg.get("azure_endpoint") and
        _cfg.get("azure_deployment") and
        _cfg.get("azure_api_key")
    )

def _anthropic_ready() -> bool:
    return bool(_cfg.get("anthropic_api_key") or os.environ.get("ANTHROPIC_API_KEY", ""))

def ai_available() -> bool:
    return _azure_ready() or _anthropic_ready()

def active_provider() -> str:
    if _azure_ready():     return "azure"
    if _anthropic_ready(): return "anthropic"
    return "none"

def active_model() -> str:
    if _azure_ready():     return _cfg.get("azure_deployment", "unknown")
    if _anthropic_ready(): return "claude-sonnet-4-20250514"
    return "none"

# ── Azure AI Foundry call ─────────────────────────────────────────────────────

def _call_azure(system: str, user: str, max_tokens: int = 800) -> Optional[str]:
    endpoint    = _cfg["azure_endpoint"].rstrip("/")
    deployment  = _cfg["azure_deployment"]
    api_key     = _cfg["azure_api_key"]
    api_version = _cfg.get("azure_api_version", "2024-08-01-preview")

    # Route to correct URL pattern based on endpoint type
    if "openai.azure.com" in endpoint:
        url = f"{endpoint}/openai/deployments/{deployment}/chat/completions?api-version={api_version}"
    elif "inference.ml.azure.com" in endpoint or "inference.ai.azure.com" in endpoint:
        url = f"{endpoint}/v1/chat/completions"
    else:
        # Generic Azure AI / custom domain — try OpenAI-compatible path
        url = f"{endpoint}/openai/deployments/{deployment}/chat/completions?api-version={api_version}"

    payload = json.dumps({
        "model": deployment,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user",   "content": user},
        ],
        "max_tokens":  max_tokens,
        "temperature": 0.2,
    }).encode("utf-8")

    req = urllib.request.Request(
        url,
        data=payload,
        headers={
            "Content-Type":  "application/json",
            "api-key":       api_key,            # Azure OpenAI header
            "Authorization": f"Bearer {api_key}", # Foundry MaaS / serverless header
        }
    )
    try:
        with urllib.request.urlopen(req, timeout=45) as resp:
            data = json.loads(resp.read())
            return data["choices"][0]["message"]["content"].strip()
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        print(f"[AI/Azure] HTTP {e.code} from {url}: {body[:400]}")
        return None
    except Exception as e:
        print(f"[AI/Azure] Call failed: {e}")
        return None

# ── Anthropic fallback call ───────────────────────────────────────────────────

def _call_anthropic(system: str, user: str, max_tokens: int = 800) -> Optional[str]:
    api_key = _cfg.get("anthropic_api_key") or os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        return None
    payload = json.dumps({
        "model": "claude-sonnet-4-20250514",
        "max_tokens": max_tokens,
        "system": system,
        "messages": [{"role": "user", "content": user}],
    }).encode("utf-8")
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=payload,
        headers={
            "Content-Type":      "application/json",
            "x-api-key":         api_key,
            "anthropic-version": "2023-06-01",
        }
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read())
            return data["content"][0]["text"].strip()
    except Exception as e:
        print(f"[AI/Anthropic] Call failed: {e}")
        return None

# ── Unified dispatcher ────────────────────────────────────────────────────────

def _call(system: str, user: str, max_tokens: int = 800) -> Optional[str]:
    if _azure_ready():
        result = _call_azure(system, user, max_tokens)
        if result:
            return result
        print("[AI] Azure call failed — trying Anthropic fallback")
    return _call_anthropic(system, user, max_tokens)

def _call_json(system: str, user: str, max_tokens: int = 800) -> Optional[dict]:
    raw = _call(system, user + "\n\nRespond with ONLY valid JSON. No markdown, no preamble.", max_tokens)
    if not raw:
        return None
    try:
        clean = re.sub(r"^```json\s*|^```\s*|```$", "", raw.strip(), flags=re.MULTILINE).strip()
        return json.loads(clean)
    except Exception as e:
        print(f"[AI] JSON parse failed: {e}\nRaw response: {raw[:300]}")
        return None

# ── Connection test ───────────────────────────────────────────────────────────

def test_connection() -> dict:
    provider = active_provider()
    model    = active_model()
    if provider == "none":
        return {"ok": False, "provider": "none", "model": "none",
                "message": "No AI provider configured. Add Azure Foundry or Anthropic credentials in Settings."}
    result = _call("You are a test assistant.", "Reply with exactly one word: OK")
    if result and "OK" in result.upper():
        return {"ok": True, "provider": provider, "model": model,
                "message": f"Connected — {provider} / {model}"}
    return {"ok": False, "provider": provider, "model": model,
            "message": f"Provider responded but unexpected reply: {result!r}"}

# ── 1. Pre-Remediation Triage ─────────────────────────────────────────────────

_TRIAGE_SYS = (
    "You are an expert NetWorker backup automation engineer. "
    "Analyse ticket data and return a JSON triage assessment. Be concise and precise. "
    "Response must be valid JSON only."
)

def triage_ticket(ticket: dict) -> dict:
    result = {
        "ai_risk_score": None, "ai_predicted_cause": None,
        "ai_priority": None,   "ai_triage_note": None,
        "ai_triage_time": datetime.now().strftime("%H:%M:%S"),
        "ai_provider": active_provider(),
    }
    if not ai_available():
        return ticket

    user = (
        f"Triage this NetWorker backup failure ticket:\n"
        f"Ticket ID  : {ticket.get('ticket_id')}\n"
        f"NW Server  : {ticket.get('nw_server')}\n"
        f"Client     : {ticket.get('client')}\n"
        f"OS         : {ticket.get('os_type', 'Unknown')}\n"
        f"Description: {ticket.get('description', 'No description')}\n"
        f"Error msg  : {ticket.get('error_message', 'None')}\n\n"
        'Return JSON: {"risk_score":<1-10>,"predicted_cause":"<root cause in 8 words or less>",'
        '"priority":"<Critical|High|Medium|Low>","triage_note":"<1 sentence actionable insight>"}'
    )
    resp = _call_json(_TRIAGE_SYS, user)
    if resp:
        result["ai_risk_score"]      = resp.get("risk_score")
        result["ai_predicted_cause"] = resp.get("predicted_cause")
        result["ai_priority"]        = resp.get("priority")
        result["ai_triage_note"]     = resp.get("triage_note")
    ticket.update(result)
    return ticket

# ── 2. Root Cause Analysis ────────────────────────────────────────────────────

_RCA_SYS = (
    "You are a senior backup infrastructure engineer writing a root cause analysis report. "
    "Be technical, precise, and actionable. Output JSON only."
)

def generate_rca(ticket: dict) -> dict:
    result = {
        "ai_root_cause": None, "ai_remediation_summary": None,
        "ai_preventive_actions": [], "ai_confidence": None,
        "ai_requires_manual_review": False,
        "ai_rca_time": datetime.now().strftime("%H:%M:%S"),
        "ai_provider": active_provider(),
    }
    if not ai_available():
        return ticket

    services_info = "".join(
        f"  - {s['service']}: {s['state']} (action: {s['action']})\n"
        for s in ticket.get("step5_services", [])
    )
    disk_info = "".join(
        f"  - {d['path']}: {d['detail']} [{d.get('flag','OK')}]\n"
        for d in ticket.get("step6_disk", [])
    )
    user = (
        f"Perform RCA for this completed NetWorker backup remediation:\n\n"
        f"Ticket: {ticket.get('ticket_id')} | Client: {ticket.get('client')} | OS: {ticket.get('os_type')}\n\n"
        f"  Reachability    : {ticket.get('step2_status')} — {ticket.get('step2_note','')}\n"
        f"  Login           : {ticket.get('step4_status')} — {ticket.get('step4_note','')}\n"
        f"  Services        : {ticket.get('step5_status')} — {ticket.get('step5_note','')}\n"
        f"{services_info}"
        f"  Disk Space      : {ticket.get('step6_status')} — {ticket.get('step6_note','')}\n"
        f"{disk_info}"
        f"  Backup Retrigger: {ticket.get('step7_status')} — {ticket.get('step7_note','')}\n\n"
        'Return JSON: {"root_cause":"<12 words max>","remediation_summary":"<1-2 sentences>",'
        '"preventive_actions":["<action 1>","<action 2>","<action 3>"],'
        '"confidence":"<High|Medium|Low>","requires_manual_review":<true|false>}'
    )
    resp = _call_json(_RCA_SYS, user, max_tokens=900)
    if resp:
        result["ai_root_cause"]             = resp.get("root_cause")
        result["ai_remediation_summary"]    = resp.get("remediation_summary")
        result["ai_preventive_actions"]     = resp.get("preventive_actions", [])
        result["ai_confidence"]             = resp.get("confidence")
        result["ai_requires_manual_review"] = resp.get("requires_manual_review", False)
    ticket.update(result)
    return ticket

# ── 3. Batch Pattern Detection ────────────────────────────────────────────────

_PATTERN_SYS = (
    "You are a NetWorker infrastructure analyst detecting patterns in backup failure data. "
    "Return JSON only. Be concise."
)

def detect_patterns(tickets: list) -> dict:
    if not tickets or not ai_available():
        return {"patterns": [], "systemic_risk": "Unknown", "summary": "AI unavailable."}

    rows = [
        {"id": t.get("ticket_id"), "client": t.get("client"), "os": t.get("os_type"),
         "status": t.get("status"), "step2": t.get("step2_status"),
         "step4": t.get("step4_status"), "step5": t.get("step5_status"),
         "step5_note": t.get("step5_note",""), "step6": t.get("step6_status"),
         "step7": t.get("step7_status"), "cause": t.get("ai_predicted_cause","")}
        for t in tickets
    ]
    user = (
        f"Analyse these {len(tickets)} NetWorker backup tickets for patterns:\n\n"
        f"{json.dumps(rows, indent=2)}\n\n"
        'Return JSON: {"patterns":[{"pattern_type":"<Service Outage|Disk Space|Auth Failure|Network|OS-Specific|Other>",'
        '"affected_count":<int>,"description":"<15 words max>","affected_tickets":["<id>",...]}],'
        '"systemic_risk":"<High|Medium|Low>","summary":"<2-3 sentence executive summary>"}'
    )
    resp = _call_json(_PATTERN_SYS, user, max_tokens=1100)
    return resp or {"patterns": [], "systemic_risk": "Unknown", "summary": "AI analysis failed."}

# ── 4. AI Close Notes ─────────────────────────────────────────────────────────

_CLOSE_SYS = (
    "You are writing close notes for a ServiceNow backup incident ticket. "
    "Write professional, concise close notes that a NOC engineer would approve. "
    "Output JSON only."
)

def generate_ai_close_notes(ticket: dict) -> str:
    if not ai_available():
        return ""
    user = (
        f"Write close notes for this backup incident:\n"
        f"Ticket: {ticket.get('ticket_id')} | Client: {ticket.get('client')} | OS: {ticket.get('os_type')}\n"
        f"Root cause: {ticket.get('ai_root_cause','Under investigation')}\n"
        f"Services: {ticket.get('step5_note','N/A')} | Disk: {ticket.get('step6_note','N/A')}\n"
        f"Backup retrigger: {ticket.get('step7_status')} — {ticket.get('step7_note','')}\n"
        f"Preventive actions: {', '.join(ticket.get('ai_preventive_actions',[]))}\n\n"
        'Return JSON: {"close_notes_paragraph":"<3-5 professional sentences>",'
        '"resolution_code":"<Resolved|Partially Resolved|Escalated|Monitoring>"}'
    )
    resp = _call_json(_CLOSE_SYS, user)
    return resp.get("close_notes_paragraph","") if resp else ""

# ── 5. Manual Step Recommendations ───────────────────────────────────────────

_RECO_SYS = (
    "You are a senior NetWorker engineer advising L2 support on manual remediation. "
    "Be specific, ordered, and actionable. Output JSON only."
)

def recommend_manual_steps(ticket: dict) -> list:
    if not ai_available():
        return []
    failed_step = next(
        (s for s in ["step2","step4","step5","step7"] if ticket.get(f"{s}_status")=="FAIL"),
        None
    )
    if not failed_step:
        return []
    step_names = {"step2":"reachability/ping","step4":"service account login",
                  "step5":"service check/restart","step7":"backup retrigger"}
    user = (
        f"Automation failed at: {step_names.get(failed_step, failed_step)}\n"
        f"Error: {ticket.get(f'{failed_step}_note','Unknown')}\n"
        f"Client: {ticket.get('client')} | OS: {ticket.get('os_type')}\n\n"
        "Provide 4-5 specific manual troubleshooting steps for an L2 engineer.\n"
        'Return JSON: {"steps":["<step 1>","<step 2>",...]}'
    )
    resp = _call_json(_RECO_SYS, user)
    return resp.get("steps",[]) if resp else []
