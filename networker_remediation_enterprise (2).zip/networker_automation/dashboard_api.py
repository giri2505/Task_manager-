"""
NetWorker Remediation Dashboard — Flask API Backend
Exposes REST endpoints that the HTML dashboard calls.
All automation steps run as real Python — this is NOT a simulation.

Run:
    pip install flask flask-cors paramiko pywinrm
    python dashboard_api.py

Then open dashboard.html in your browser.
"""

import json
import os
import threading
import time
from datetime import datetime
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

# Import automation steps
from step1_parse_ticket     import parse_from_csv, parse_single
from step2_reachability     import ping_host
from step3_identify_os      import identify_os
from step4_login            import login, ssh_login, winrm_login, run_ssh_command, run_winrm_command
from step5_service_check    import check_services, LINUX_SERVICES, WINDOWS_SERVICES
from step6_disk_check       import check_disk
from step7_retrigger_backup import retrigger_backup
from step8_close_notes      import build_close_note

# AI Analysis module — Azure AI Foundry (primary) + Anthropic (fallback)
try:
    from ai_analysis import (configure as ai_configure,
                              triage_ticket, generate_rca, detect_patterns,
                              generate_ai_close_notes, recommend_manual_steps,
                              ai_available, active_provider, active_model,
                              test_connection as ai_test_connection)
    AI_MODULE_LOADED = True
except ImportError:
    AI_MODULE_LOADED = False
    def ai_configure(cfg): pass
    def triage_ticket(t): return t
    def generate_rca(t): return t
    def detect_patterns(ts): return {}
    def generate_ai_close_notes(t): return ""
    def recommend_manual_steps(t): return []
    def ai_available(): return False
    def active_provider(): return "none"
    def active_model(): return "none"
    def ai_test_connection(): return {"ok": False, "message": "ai_analysis.py not found"}

def _inject_ai_config():
    """Push latest config into ai_analysis before each call.""\"
    ai_configure(load_config())

app = Flask(__name__)
CORS(app)

# ── In-memory ticket store ────────────────────────────────────────────────
tickets: dict[str, dict] = {}          # ticket_id → ticket dict
run_logs: dict[str, list] = {}         # ticket_id → list of log lines
running_jobs: dict[str, bool] = {}     # ticket_id → True if actively running

# ── Config (loaded from config.json if present) ───────────────────────────
CONFIG_FILE = os.path.join(os.path.dirname(__file__), 'dashboard_config.json')

def load_config() -> dict:
    defaults = {
        'username':         '',
        # Linux SSH — service account key file (RECOMMENDED)
        # Set auth_method to 'key_file' and provide key_path for production use
        # key_file  = SSH private key (e.g. /home/automation/.ssh/id_ed25519)
        # key_text  = paste private key text (for secrets-manager / vault injection)
        'auth_method':      'key_file',
        'key_path':         '',      # e.g. /home/svc_networker/.ssh/id_ed25519
        'key_text':         '',      # alternative: paste raw key content
        'password':         '',      # only for passphrase-protected keys or fallback
        # Jump host (bastion) — optional
        'jump_host':        '',
        'jump_user':        '',
        'jump_password':    '',
        'jump_key_path':    '',
        # Vault — optional
        'vault_addr':       '',
        'vault_token':      '',
        'vault_role':       '',
        # Windows WinRM — PAM/RDP service account
        # ntlm      = works with any domain account (incl. PAM-managed RDP accounts)
        # kerberos  = AD SSO, run kinit svc@DOMAIN.COM first
        # credssp   = double-hop (run kinit + enable CredSSP on hosts)
        'winrm_auth':       'ntlm',   # ntlm | kerberos | credssp | certificate
        'winrm_ssl':        False,
        'cert_pem':         '',
        'cert_key_pem':     '',
        # AI — Azure AI Foundry (primary)
        'azure_endpoint':    '',   # e.g. https://my-resource.openai.azure.com/ or Foundry URL
        'azure_deployment':  '',   # e.g. gpt-4o  or  Phi-4  or  Mistral-Large-2407
        'azure_api_key':     '',
        'azure_api_version': '2024-08-01-preview',
        # AI — Anthropic Claude (fallback)
        'anthropic_api_key': os.environ.get('ANTHROPIC_API_KEY', ''),
        # Pipeline
        'dry_run':          False,
        'min_disk_gb':      10,
        'linux_services':   LINUX_SERVICES,
        'windows_services': WINDOWS_SERVICES,
        # AI feature flags
        'ai_triage_enabled': True,
        'ai_rca_enabled':    True,
    }
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE) as f:
            saved = json.load(f)
        defaults.update(saved)
    return defaults

def save_config(cfg: dict):
    with open(CONFIG_FILE, 'w') as f:
        json.dump(cfg, f, indent=2)


def log(ticket_id: str, msg: str):
    """Append a timestamped log line for a ticket."""
    ts = datetime.now().strftime('%H:%M:%S')
    line = f"[{ts}] {msg}"
    run_logs.setdefault(ticket_id, []).append(line)
    print(f"[{ticket_id}] {msg}")


# ─────────────────────────────────────────────────────────────────────────
# Ticket CRUD
# ─────────────────────────────────────────────────────────────────────────

@app.route('/api/tickets', methods=['GET'])
def get_tickets():
    return jsonify(list(tickets.values()))


@app.route('/api/tickets', methods=['POST'])
def add_ticket():
    data = request.json
    tid = data.get('ticket_id', '').strip()
    if not tid:
        return jsonify({'error': 'ticket_id required'}), 400
    if tid in tickets:
        return jsonify({'error': f'Ticket {tid} already exists'}), 409
    t = {
        'ticket_id': tid,
        'nw_server': data.get('nw_server', '').strip(),
        'client':    data.get('client', '').strip(),
        'os_type':   data.get('os_type', 'Unknown'),
        'status':    'New',
        'created':   datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'updated':   datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'steps_done': 0,
    }
    tickets[tid] = t
    run_logs[tid] = []
    return jsonify(t), 201


@app.route('/api/tickets/import', methods=['POST'])
def import_csv():
    """Accept CSV file upload and parse tickets."""
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
    f = request.files['file']
    tmp_path = f'/tmp/snow_import_{int(time.time())}.csv'
    f.save(tmp_path)
    try:
        parsed = parse_from_csv(tmp_path)
        added = 0
        for t in parsed:
            tid = t['ticket_id']
            if tid not in tickets:
                t.update({'status': 'New', 'created': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                          'updated': datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'steps_done': 0})
                tickets[tid] = t
                run_logs[tid] = []
                added += 1
        os.remove(tmp_path)
        return jsonify({'imported': added, 'total': len(parsed)})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/tickets/<tid>', methods=['DELETE'])
def delete_ticket(tid):
    tickets.pop(tid, None)
    run_logs.pop(tid, None)
    running_jobs.pop(tid, None)
    return jsonify({'deleted': tid})


@app.route('/api/tickets/<tid>/logs', methods=['GET'])
def get_logs(tid):
    return jsonify(run_logs.get(tid, []))


# ─────────────────────────────────────────────────────────────────────────
# Config
# ─────────────────────────────────────────────────────────────────────────

@app.route('/api/config', methods=['GET'])
def get_config():
    cfg = load_config()
    # Mask secrets — client gets placeholder so it knows a value is saved
    for key in ('password', 'key_text', 'jump_password', 'vault_token',
               'azure_api_key', 'anthropic_api_key'):
        if cfg.get(key):
            cfg[key] = '__saved__'
    return jsonify(cfg)


@app.route('/api/config', methods=['POST'])
def set_config():
    cfg = load_config()
    data = request.json
    # Don't overwrite saved secrets with placeholder
    for key in ('password', 'key_text', 'jump_password', 'vault_token',
               'azure_api_key', 'anthropic_api_key'):
        if data.get(key) == '__saved__':
            data.pop(key)
    cfg.update({k: v for k, v in data.items() if v is not None})
    save_config(cfg)
    return jsonify({'saved': True})


@app.route('/api/test-connection', methods=['POST'])
def test_connection():
    """Quick connectivity + login test using saved config."""
    cfg = load_config()
    username = cfg.get('username', '')
    if not username:
        return jsonify({'ok': False, 'error': 'No username configured. Go to Settings first.'})

    sample = next((t for t in tickets.values()), None)
    if not sample:
        return jsonify({'ok': True, 'message': 'Config saved. Add a ticket to test a real connection.'})

    from step2_reachability import ping_host
    from step4_login import login as do_login

    client = sample['client']
    if not ping_host(client, retries=1):
        return jsonify({'ok': False, 'error': f'Cannot reach {client} — check network/firewall.'})

    auth_kw = dict(
        auth_method   = cfg.get('auth_method', 'password'),
        password      = cfg.get('password') or None,
        key_path      = cfg.get('key_path') or None,
        key_text      = cfg.get('key_text') or None,
        jump_host     = cfg.get('jump_host') or None,
        jump_user     = cfg.get('jump_user') or None,
        jump_password = cfg.get('jump_password') or None,
        jump_key_path = cfg.get('jump_key_path') or None,
        vault_addr    = cfg.get('vault_addr') or None,
        vault_token   = cfg.get('vault_token') or None,
        vault_role    = cfg.get('vault_role') or None,
        winrm_auth    = cfg.get('winrm_auth', 'ntlm'),
        use_ssl       = cfg.get('winrm_ssl', False),
        cert_pem      = cfg.get('cert_pem') or None,
        cert_key_pem  = cfg.get('cert_key_pem') or None,
    )
    test_t = dict(sample)
    do_login(test_t, username, **auth_kw)
    conn = test_t.pop('_conn', None)
    if conn:
        try: conn.close()
        except: pass
    if test_t.get('step4_status') == 'PASS':
        return jsonify({'ok': True, 'message': test_t['step4_note']})
    return jsonify({'ok': False, 'error': test_t.get('step4_note', 'Login failed')})


# ─────────────────────────────────────────────────────────────────────────
# Automation runner (runs in background thread per ticket)
# ─────────────────────────────────────────────────────────────────────────

def run_ticket_pipeline(tid: str):
    """Background thread — runs all 8 steps for one ticket."""
    t = tickets.get(tid)
    if not t:
        return

    cfg = load_config()
    username     = cfg.get('username', '')
    dry_run      = cfg.get('dry_run', False)
    # Build full auth kwargs dict from config — passed to login/check_services/etc.
    auth_kwargs = dict(
        auth_method  = cfg.get('auth_method', 'password'),
        password     = cfg.get('password') or None,
        key_path     = cfg.get('key_path') or None,
        key_text     = cfg.get('key_text') or None,
        jump_host    = cfg.get('jump_host') or None,
        jump_user    = cfg.get('jump_user') or None,
        jump_password= cfg.get('jump_password') or None,
        jump_key_path= cfg.get('jump_key_path') or None,
        vault_addr   = cfg.get('vault_addr') or None,
        vault_token  = cfg.get('vault_token') or None,
        vault_role   = cfg.get('vault_role') or None,
        winrm_auth   = cfg.get('winrm_auth', 'ntlm'),
        use_ssl      = cfg.get('winrm_ssl', False),
        cert_pem     = cfg.get('cert_pem') or None,
        cert_key_pem = cfg.get('cert_key_pem') or None,
    )

    running_jobs[tid] = True
    t['status'] = 'Running'
    t['steps_done'] = 0
    t['updated'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    run_logs[tid] = []

    def update(step_num, status, note=''):
        t[f'step{step_num}_status'] = status
        t[f'step{step_num}_note']   = note
        t['steps_done'] = step_num
        t['updated'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    try:
        # ── Step 1: Parse ────────────────────────────────────────────────
        log(tid, 'Step 1: Parsing ticket fields...')
        t['step1_status'] = 'PASS'
        t['step1_note']   = f"Server: {t['nw_server']} | Client: {t['client']}"
        t['steps_done'] = 1
        log(tid, f"  ✓ NW Server: {t['nw_server']}  Client: {t['client']}")

        # ── AI Triage (pre-remediation) ──────────────────────────────────
        _inject_ai_config()
        if cfg.get('ai_triage_enabled', True):
            log(tid, 'AI: Running pre-remediation triage...')
            try:
                triage_ticket(t)
                if t.get('ai_priority'):
                    log(tid, f"  🤖 AI Risk: {t.get('ai_risk_score')}/10 | Priority: {t.get('ai_priority')} | Predicted: {t.get('ai_predicted_cause', 'unknown')}")
            except Exception as ae:
                log(tid, f"  ⚠ AI triage skipped: {ae}")

        # ── Step 2: Reachability ─────────────────────────────────────────
        log(tid, f"Step 2: Pinging {t['client']}...")
        reachable = ping_host(t['client'])
        t['reachable'] = reachable
        if reachable:
            update(2, 'PASS', f"{t['client']} is reachable")
            log(tid, f"  ✓ Host is reachable")
        else:
            update(2, 'FAIL', f"Host {t['client']} unreachable — ICMP timeout")
            t['status'] = 'Unreachable'
            log(tid, f"  ✗ Host UNREACHABLE — stopping")
            _finish(t, tid)
            return

        # ── Step 3: OS Identification ─────────────────────────────────────
        log(tid, f"Step 3: Identifying OS for {t['client']}...")
        os_type = identify_os(t['client'], t.get('os_type', 'Unknown'))
        t['os_type'] = os_type
        update(3, 'PASS', f"Identified as {os_type}")
        log(tid, f"  ✓ OS: {os_type}")

        # ── Step 4: Login ─────────────────────────────────────────────────
        log(tid, f"Step 4: Logging in as {username}...")
        login(t, username, **auth_kwargs)
        t.pop('_conn', None)
        if t.get('step4_status') != 'PASS':
            t['status'] = 'Failed'
            log(tid, f"  ✗ Login failed: {t.get('step4_note')}")
            _finish(t, tid)
            return
        update(4, 'PASS', t.get('step4_note', ''))
        log(tid, f"  ✓ Login successful")

        # ── Step 5: Service Check ─────────────────────────────────────────
        log(tid, 'Step 5: Checking backup services...')
        check_services(t, username, **auth_kwargs)
        s5 = t.get('step5_status', 'FAIL')
        log(tid, f"  {'✓' if s5 == 'PASS' else '⚠'} Services: {t.get('step5_note', '')}")
        # Log each service result
        for svc in t.get('step5_services', []):
            icon = '✓' if svc['action'] in ('none',) else '↺' if svc['action'] == 'restarted' else '✗'
            log(tid, f"    {icon} {svc['service']}: {svc['state']}")

        # ── Step 6: Disk Space ────────────────────────────────────────────
        log(tid, 'Step 6: Checking disk space...')
        check_disk(t, username, **auth_kwargs)
        s6 = t.get('step6_status', 'FAIL')
        log(tid, f"  {'🔴' if s6 == 'RED' else '✓'} Disk: {t.get('step6_note', '')}")
        for d in t.get('step6_disk', []):
            log(tid, f"    {'🔴' if d['flag']=='RED' else '✓'} {d['path']}: {d['detail']}")

        # ── Step 7: Retrigger Backup ──────────────────────────────────────
        if t.get('step5_status') == 'FAIL':
            t['step7_status'] = 'SKIPPED'
            t['step7_note']   = 'Skipped — service restart failed'
            log(tid, 'Step 7: SKIPPED — service restart failed')
        else:
            log(tid, f"Step 7: Retriggering backup on {t['nw_server']}...")
            retrigger_backup(t, username, dry_run=dry_run, **auth_kwargs)
            s7 = t.get('step7_status', 'FAIL')
            log(tid, f"  {'✓' if s7 == 'PASS' else '✗'} Retrigger: {t.get('step7_note', '')}")
        t['steps_done'] = 7

        # ── Step 8: Close Notes ───────────────────────────────────────────
        log(tid, 'Step 8: Generating close notes...')
        t['close_notes'] = build_close_note(t)
        t['steps_done'] = 8
        log(tid, '  ✓ Close notes generated')

        # ── AI RCA (post-remediation) ─────────────────────────────────────
        if cfg.get('ai_rca_enabled', True):
            log(tid, 'AI: Running root cause analysis...')
            try:
                generate_rca(t)
                if t.get('ai_root_cause'):
                    log(tid, f"  🤖 RCA: {t.get('ai_root_cause')} (confidence: {t.get('ai_confidence','?')})")
                ai_note = generate_ai_close_notes(t)
                if ai_note:
                    t['ai_close_notes'] = ai_note
                if t.get('status') == 'Failed':
                    steps = recommend_manual_steps(t)
                    t['ai_manual_steps'] = steps
                    if steps:
                        log(tid, f"  🤖 {len(steps)} manual remediation steps suggested")
            except Exception as ae:
                log(tid, f"  ⚠ AI RCA skipped: {ae}")

        _finish(t, tid)

    except Exception as e:
        log(tid, f'  ✗ UNEXPECTED ERROR: {e}')
        t['status'] = 'Failed'
        t['error']  = str(e)
        running_jobs[tid] = False


def _finish(t: dict, tid: str):
    """Set final status after pipeline completes."""
    if t['status'] not in ('Unreachable', 'Failed'):
        s7  = t.get('step7_status', 'SKIPPED')
        s6  = t.get('step6_status', 'PASS')
        s5  = t.get('step5_status', 'PASS')
        if s7 == 'PASS' and s5 == 'PASS' and s6 != 'RED':
            t['status'] = 'Remediated'
        elif s7 == 'PASS' and s6 == 'RED':
            t['status'] = 'Partial'
        elif s7 in ('FAIL',):
            t['status'] = 'Failed'
        else:
            t['status'] = 'Remediated'
    t['updated'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    running_jobs[tid] = False
    log(tid, f'Pipeline complete — Final status: {t["status"]}')


@app.route('/api/tickets/<tid>/run', methods=['POST'])
def run_ticket(tid):
    if tid not in tickets:
        return jsonify({'error': 'Ticket not found'}), 404
    if running_jobs.get(tid):
        return jsonify({'error': 'Already running'}), 409
    cfg = load_config()
    if not cfg.get('username'):
        return jsonify({'error': 'Service account not configured. Go to Settings tab.'}), 400
    thread = threading.Thread(target=run_ticket_pipeline, args=(tid,), daemon=True)
    thread.start()
    return jsonify({'started': tid})


@app.route('/api/run-all', methods=['POST'])
def run_all():
    new_tickets = [t for t in tickets.values() if t['status'] == 'New']
    started = []
    for t in new_tickets:
        tid = t['ticket_id']
        if not running_jobs.get(tid):
            thread = threading.Thread(target=run_ticket_pipeline, args=(tid,), daemon=True)
            thread.start()
            started.append(tid)
    return jsonify({'started': started})


@app.route('/api/tickets/<tid>/close-notes', methods=['GET'])
def get_close_notes(tid):
    t = tickets.get(tid)
    if not t:
        return jsonify({'error': 'Not found'}), 404
    return jsonify({'close_notes': t.get('close_notes', 'Not yet generated.')})


@app.route('/api/export', methods=['GET'])
def export_results():
    """Export all ticket results as JSON."""
    return jsonify(list(tickets.values()))


# ─────────────────────────────────────────────────────────────────────────────
# AI Endpoints
# ─────────────────────────────────────────────────────────────────────────────

@app.route('/api/ai/status', methods=['GET'])
def ai_status():
    """Check AI provider status — Azure Foundry first, Anthropic fallback."""
    _inject_ai_config()
    return jsonify({
        'available': ai_available(),
        'provider':  active_provider(),
        'model':     active_model(),
    })


@app.route('/api/ai/test', methods=['POST'])
def ai_test():
    """Test the configured AI provider (Azure Foundry or Anthropic)."""
    _inject_ai_config()
    result = ai_test_connection()
    return jsonify(result)


@app.route('/api/ai/triage/<tid>', methods=['POST'])
def ai_triage(tid):
    """Run AI triage on a single ticket."""
    t = tickets.get(tid)
    if not t:
        return jsonify({'error': 'Ticket not found'}), 404
    cfg = load_config()
    # inject key into env if stored in config
    if cfg.get('anthropic_api_key'):
        os.environ['ANTHROPIC_API_KEY'] = cfg['anthropic_api_key']
    try:
        triage_ticket(t)
        return jsonify({
            'ai_risk_score': t.get('ai_risk_score'),
            'ai_predicted_cause': t.get('ai_predicted_cause'),
            'ai_priority': t.get('ai_priority'),
            'ai_triage_note': t.get('ai_triage_note'),
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/ai/rca/<tid>', methods=['POST'])
def ai_rca(tid):
    """Run AI root cause analysis on a completed ticket."""
    t = tickets.get(tid)
    if not t:
        return jsonify({'error': 'Ticket not found'}), 404
    _inject_ai_config()
    try:
        generate_rca(t)
        steps = recommend_manual_steps(t) if t.get('status') == 'Failed' else []
        t['ai_manual_steps'] = steps
        ai_note = generate_ai_close_notes(t)
        if ai_note:
            t['ai_close_notes'] = ai_note
        return jsonify({
            'ai_root_cause': t.get('ai_root_cause'),
            'ai_remediation_summary': t.get('ai_remediation_summary'),
            'ai_preventive_actions': t.get('ai_preventive_actions', []),
            'ai_confidence': t.get('ai_confidence'),
            'ai_requires_manual_review': t.get('ai_requires_manual_review'),
            'ai_manual_steps': steps,
            'ai_close_notes': t.get('ai_close_notes', ''),
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/ai/patterns', methods=['POST'])
def ai_patterns():
    """Detect patterns across all tickets."""
    _inject_ai_config()
    try:
        all_tickets = list(tickets.values())
        result = detect_patterns(all_tickets)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/ai/manual-steps/<tid>', methods=['GET'])
def ai_manual_steps(tid):
    """Get AI-recommended manual troubleshooting steps for a failed ticket."""
    t = tickets.get(tid)
    if not t:
        return jsonify({'error': 'Ticket not found'}), 404
    cfg = load_config()
    if cfg.get('anthropic_api_key'):
        os.environ['ANTHROPIC_API_KEY'] = cfg['anthropic_api_key']
    steps = recommend_manual_steps(t)
    t['ai_manual_steps'] = steps
    return jsonify({'steps': steps})


@app.route('/')
def serve_dashboard():
    return send_from_directory(os.path.dirname(__file__), 'dashboard.html')


if __name__ == '__main__':
    print("="*55)
    print(" NetWorker Remediation Dashboard API")
    print(" http://localhost:5050")
    print("="*55)
    app.run(host='0.0.0.0', port=5050, debug=False)
