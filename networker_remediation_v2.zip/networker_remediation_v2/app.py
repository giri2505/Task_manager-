"""
app.py — NetWorker Remediation Application Server
Run this once on your server: python app.py
It starts a web server on port 5050 (configurable in Settings).
No CLI parameters required — everything configured via the dashboard.
"""

import json
import os
import sys
import threading
import time
from datetime import datetime
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

# Add parent dir to path so imports work when run from any directory
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import config
from ai.engine import parse_ticket, analyse_trends
from core.pipeline import run_pipeline, step_reachability

app = Flask(__name__, static_folder="static")
CORS(app)

# ── In-memory stores (persist to disk via tickets.json) ───────────────────────
_tickets: dict[str, dict] = {}
_logs:    dict[str, list] = {}
_running: dict[str, bool] = {}
TICKETS_FILE = os.path.join(os.path.dirname(__file__), "tickets.json")


def _save_tickets():
    safe = {tid: {k: v for k, v in t.items() if not k.startswith("_")}
            for tid, t in _tickets.items()}
    with open(TICKETS_FILE, "w") as f:
        json.dump(safe, f, indent=2)


def _load_tickets():
    global _tickets
    if os.path.exists(TICKETS_FILE):
        try:
            with open(TICKETS_FILE) as f:
                _tickets = json.load(f)
            print(f"[STARTUP] Loaded {len(_tickets)} tickets from disk")
        except Exception as e:
            print(f"[STARTUP] Could not load tickets.json: {e}")


def _log(tid: str, msg: str):
    ts   = datetime.now().strftime("%H:%M:%S")
    line = f"[{ts}] {msg}"
    _logs.setdefault(tid, []).append(line)


# ─────────────────────────────────────────────────────────────────────────────
# Serve dashboard
# ─────────────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return send_from_directory(os.path.dirname(__file__), "dashboard.html")


# ─────────────────────────────────────────────────────────────────────────────
# Tickets API
# ─────────────────────────────────────────────────────────────────────────────

@app.route("/api/tickets", methods=["GET"])
def get_tickets():
    return jsonify(list(_tickets.values()))


@app.route("/api/tickets", methods=["POST"])
def add_ticket():
    """Add a ticket manually or from a parsed result."""
    data = request.json or {}
    tid  = data.get("ticket_id", "").strip()
    if not tid:
        return jsonify({"error": "ticket_id required"}), 400
    if tid in _tickets:
        return jsonify({"error": f"{tid} already exists"}), 409

    t = {
        "ticket_id":   tid,
        "nw_server":   data.get("nw_server", "").strip(),
        "client":      data.get("client", "").strip(),
        "os_type":     data.get("os_type", "Unknown"),
        "raw_text":    data.get("raw_text", ""),
        "error_summary": data.get("error_summary", ""),
        "priority":    data.get("priority", "P3"),
        "status":      "New",
        "steps_done":  0,
        "step_results": [],
        "created":     datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "updated":     datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    _tickets[tid] = t
    _logs[tid]    = []
    _save_tickets()

    # Auto-run if configured
    if config.get("auto_run_new"):
        _start_pipeline(tid)

    return jsonify(t), 201


@app.route("/api/tickets/ai-parse", methods=["POST"])
def ai_parse_ticket():
    """
    Accept raw ticket text (or structured fields) and use GPT-4o to parse it.
    Returns parsed fields — user can review before adding to the system.
    """
    data       = request.json or {}
    raw_text   = data.get("raw_text", "")
    structured = data.get("structured_fields", {})

    if not raw_text and not structured:
        return jsonify({"error": "Provide raw_text or structured_fields"}), 400

    parsed = parse_ticket(raw_text, structured)
    return jsonify(parsed)


@app.route("/api/tickets/import-csv", methods=["POST"])
def import_csv():
    """Import tickets from a ServiceNow CSV file. Uses AI to parse each row."""
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    import csv, io as _io
    f = request.files["file"]
    content = f.read().decode("utf-8-sig")
    reader  = csv.DictReader(_io.StringIO(content))

    added = 0
    for row in reader:
        # Build structured fields from CSV columns (handles various column names)
        structured = {k.lower().strip(): v for k, v in row.items() if v.strip()}

        # Try to find ticket ID
        tid = (structured.get("number") or structured.get("ticket id") or
               structured.get("ticket_id") or structured.get("inc") or "").strip()
        if not tid or tid in _tickets:
            continue

        # Combine all fields into raw text for AI parsing
        raw_text = "\n".join(f"{k}: {v}" for k, v in structured.items())

        parsed = parse_ticket(raw_text, structured)
        parsed["ticket_id"] = parsed.get("ticket_id") or tid
        parsed["raw_text"]  = raw_text
        parsed.setdefault("status", "New")
        parsed.setdefault("steps_done", 0)
        parsed.setdefault("step_results", [])
        parsed["created"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        parsed["updated"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        real_tid = parsed["ticket_id"]
        _tickets[real_tid] = parsed
        _logs[real_tid]    = []
        added += 1

    _save_tickets()
    return jsonify({"imported": added, "total_in_file": added})


@app.route("/api/tickets/<tid>", methods=["DELETE"])
def delete_ticket(tid):
    _tickets.pop(tid, None)
    _logs.pop(tid, None)
    _running.pop(tid, None)
    _save_tickets()
    return jsonify({"deleted": tid})


@app.route("/api/tickets/<tid>/logs", methods=["GET"])
def get_logs(tid):
    return jsonify(_logs.get(tid, []))


@app.route("/api/tickets/<tid>/close-notes", methods=["GET"])
def get_close_notes(tid):
    t = _tickets.get(tid)
    if not t:
        return jsonify({"error": "Not found"}), 404
    return jsonify({"close_notes": t.get("close_notes", "Not yet generated.")})


@app.route("/api/tickets/<tid>/workorder", methods=["GET"])
def get_workorder(tid):
    t = _tickets.get(tid)
    if not t:
        return jsonify({"error": "Not found"}), 404
    return jsonify({"workorder": t.get("rdp_workorder", "Not generated yet.")})


# ─────────────────────────────────────────────────────────────────────────────
# Pipeline execution
# ─────────────────────────────────────────────────────────────────────────────

def _start_pipeline(tid: str):
    """Kick off pipeline in background thread."""
    if _running.get(tid):
        return
    t = threading.Thread(target=_run_pipeline_thread, args=(tid,), daemon=True)
    t.start()


def _run_pipeline_thread(tid: str):
    t = _tickets.get(tid)
    if not t:
        return
    _running[tid] = True
    _logs[tid]    = []

    def log_fn(msg):
        _log(tid, msg)

    try:
        result = run_pipeline(t, log_fn=log_fn)
        _tickets[tid] = result
        _save_tickets()
    except Exception as e:
        _log(tid, f"PIPELINE ERROR: {e}")
        _tickets[tid]["status"] = "Failed"
        _tickets[tid]["error"]  = str(e)
        _save_tickets()
    finally:
        _running[tid] = False


@app.route("/api/tickets/<tid>/run", methods=["POST"])
def run_ticket(tid):
    if tid not in _tickets:
        return jsonify({"error": "Ticket not found"}), 404
    if _running.get(tid):
        return jsonify({"error": "Already running"}), 409
    cfg = config.load()
    if not cfg.get("linux_username"):
        return jsonify({"error": "Service account not configured — go to Settings"}), 400
    _start_pipeline(tid)
    return jsonify({"started": tid})


@app.route("/api/run-all", methods=["POST"])
def run_all():
    new_tickets = [t for t in _tickets.values() if t["status"] == "New"]
    started = []
    for t in new_tickets:
        tid = t["ticket_id"]
        if not _running.get(tid):
            _start_pipeline(tid)
            started.append(tid)
    return jsonify({"started": started})


# ─────────────────────────────────────────────────────────────────────────────
# Analytics
# ─────────────────────────────────────────────────────────────────────────────

@app.route("/api/analytics", methods=["GET"])
def get_analytics():
    """Return ticket statistics for the dashboard charts."""
    all_t = list(_tickets.values())
    statuses = {}
    os_types = {}
    root_causes = {}
    daily = {}

    for t in all_t:
        s = t.get("status", "Unknown")
        statuses[s] = statuses.get(s, 0) + 1

        o = t.get("os_type", "Unknown")
        os_types[o] = os_types.get(o, 0) + 1

        rc = t.get("root_cause", "Unknown")
        root_causes[rc] = root_causes.get(rc, 0) + 1

        day = (t.get("created") or t.get("updated", ""))[:10]
        if day:
            daily[day] = daily.get(day, 0) + 1

    return jsonify({
        "total":        len(all_t),
        "statuses":     statuses,
        "os_types":     os_types,
        "root_causes":  root_causes,
        "daily_counts": dict(sorted(daily.items())[-14:]),  # last 14 days
        "resolution_rate": round(
            len([t for t in all_t if t.get("status") == "Remediated"]) / max(len(all_t), 1) * 100, 1
        ),
    })


@app.route("/api/analytics/rca", methods=["POST"])
def run_rca():
    """Run AI root cause analysis across all completed tickets."""
    all_t = [t for t in _tickets.values()
             if t.get("status") in ("Remediated", "Partial", "Failed", "Unreachable")]
    result = analyse_trends(all_t)
    return jsonify(result)


# ─────────────────────────────────────────────────────────────────────────────
# Settings
# ─────────────────────────────────────────────────────────────────────────────

@app.route("/api/config", methods=["GET"])
def get_config():
    cfg = config.load()
    # Mask secrets
    for key in ("linux_password", "linux_key_text", "azure_openai_api_key",
                "snow_password", "vault_token"):
        if cfg.get(key):
            cfg[key] = "__saved__"
    return jsonify(cfg)


@app.route("/api/config", methods=["POST"])
def set_config():
    data = request.json or {}
    # Don't overwrite saved secrets with placeholder
    for key in ("linux_password", "linux_key_text", "azure_openai_api_key",
                "snow_password", "vault_token"):
        if data.get(key) == "__saved__":
            data.pop(key)
    config.save(data)
    return jsonify({"saved": True})


@app.route("/api/test-connection", methods=["POST"])
def test_connection():
    """Test SSH login against a sample ticket client, or just ping."""
    sample = next((t for t in _tickets.values()), None)
    if not sample:
        return jsonify({"ok": True, "message": "Config saved. Add a ticket to test a real connection."})

    client = sample.get("client", "")
    r = step_reachability(client)
    if r["status"] != "PASS":
        return jsonify({"ok": False, "error": r["note"]})

    if sample.get("os_type") == "Windows":
        return jsonify({"ok": True, "message": f"Windows host {client} is reachable (RDP only — no SSH test)"})

    from core.linux import test_login
    result = test_login(client)
    if result["status"] == "PASS":
        return jsonify({"ok": True, "message": result["note"]})
    return jsonify({"ok": False, "error": result["note"]})


@app.route("/api/test-ai", methods=["POST"])
def test_ai():
    """Test Azure OpenAI connection with a simple call."""
    from ai.engine import _call_openai
    try:
        resp = _call_openai(
            [{"role": "user", "content": "Reply with exactly: AI connection OK"}],
            max_tokens=20
        )
        return jsonify({"ok": True, "message": resp.strip()})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


@app.route("/api/export", methods=["GET"])
def export_all():
    return jsonify(list(_tickets.values()))


# ─────────────────────────────────────────────────────────────────────────────
# Startup
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    _load_tickets()
    cfg  = config.load()
    host = cfg.get("server_host", "0.0.0.0")
    port = int(cfg.get("server_port", 5050))
    print("=" * 55)
    print("  NetWorker Backup Remediation System")
    print(f"  http://{host}:{port}")
    print("=" * 55)
    app.run(host=host, port=port, debug=False, threaded=True)
