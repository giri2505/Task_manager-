"""
core/pipeline.py — AI-driven remediation pipeline
No CLI parameters. The AI plans the steps, Linux automation executes them,
Windows gets a structured RDP work order.
"""

import socket
import subprocess
import platform
from datetime import datetime
import config
from ai.engine import plan_steps, write_close_notes, generate_rdp_workorder
from core.linux import test_login, check_services, check_disk, retrigger_backup


# ─────────────────────────────────────────────────────────────────────────────
# Reachability
# ─────────────────────────────────────────────────────────────────────────────

def _ping(hostname: str) -> bool:
    """ICMP ping. Returns True if host responds."""
    retries = config.get("ping_retries", 3)
    timeout = config.get("ping_timeout_sec", 3)
    os_name = platform.system().lower()
    for _ in range(retries):
        cmd = (["ping", "-n", "1", "-w", str(timeout * 1000), hostname]
               if os_name == "windows"
               else ["ping", "-c", "1", "-W", str(timeout), hostname])
        try:
            r = subprocess.run(cmd, stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL, timeout=timeout + 2)
            if r.returncode == 0:
                return True
        except Exception:
            pass
    return False


def step_reachability(hostname: str) -> dict:
    reachable = _ping(hostname)
    return {
        "step":   "reachability",
        "status": "PASS" if reachable else "FAIL",
        "note":   f"{hostname} is {'reachable' if reachable else 'UNREACHABLE — host offline or blocked'}",
    }


# ─────────────────────────────────────────────────────────────────────────────
# OS detection
# ─────────────────────────────────────────────────────────────────────────────

def _check_port(hostname: str, port: int, timeout: int = 4) -> bool:
    try:
        with socket.create_connection((hostname, port), timeout=timeout):
            return True
    except Exception:
        return False


def step_os_detect(hostname: str, hint: str = "Unknown") -> dict:
    if hint in ("Windows", "Linux"):
        return {"step": "os_detect", "status": "PASS",
                "note": f"OS known from ticket: {hint}", "os_type": hint}
    if _check_port(hostname, 22):
        return {"step": "os_detect", "status": "PASS",
                "note": "SSH port 22 open → Linux", "os_type": "Linux"}
    if _check_port(hostname, 5985) or _check_port(hostname, 5986) or _check_port(hostname, 3389):
        return {"step": "os_detect", "status": "PASS",
                "note": "WinRM/RDP port open → Windows", "os_type": "Windows"}
    return {"step": "os_detect", "status": "PASS",
            "note": "Could not detect OS — defaulting to Linux", "os_type": "Linux"}


# ─────────────────────────────────────────────────────────────────────────────
# RDP work order (Windows)
# ─────────────────────────────────────────────────────────────────────────────

def step_rdp_workorder(ticket: dict) -> dict:
    workorder = generate_rdp_workorder(ticket)
    return {
        "step":      "rdp_workorder",
        "status":    "MANUAL",
        "note":      "Windows client — manual RDP investigation required",
        "workorder": workorder,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Main pipeline runner
# ─────────────────────────────────────────────────────────────────────────────

STEP_LABELS = {
    "reachability": "Reachability check",
    "os_detect":    "OS identification",
    "ssh_login":    "Service account login",
    "service_check":"Service health check",
    "disk_check":   "Disk space check",
    "retrigger":    "Retrigger backup",
    "rdp_workorder":"RDP work order (Windows)",
}


def run_pipeline(ticket: dict, log_fn=None) -> dict:
    """
    AI-driven pipeline for a single ticket.

    1. AI plans the steps based on ticket content
    2. Each step is executed in order
    3. AI writes the close notes from results
    4. Returns updated ticket dict

    log_fn: optional callable(str) for real-time log streaming
    """
    def log(msg: str):
        ts = datetime.now().strftime("%H:%M:%S")
        line = f"[{ts}] {msg}"
        if log_fn:
            log_fn(line)
        print(line)

    ticket = dict(ticket)
    ticket["status"]     = "Running"
    ticket["step_results"] = []
    ticket["updated"]    = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    client    = ticket.get("client", "")
    nw_server = ticket.get("nw_server", "")
    os_type   = ticket.get("os_type", "Unknown")

    # ── AI step planning ────────────────────────────────────────────────
    log("AI: Planning remediation steps...")
    plan = plan_steps(ticket)
    ticket["ai_plan"]   = plan
    ticket["steps_plan"] = plan.get("steps", [])
    log(f"AI plan: {plan.get('steps')} — {plan.get('rationale')}")

    steps_to_run = plan.get("steps", ["reachability"])
    completed    = 0
    total        = len(steps_to_run)

    for step_name in steps_to_run:
        log(f"Running step {completed+1}/{total}: {STEP_LABELS.get(step_name, step_name)}...")
        ticket["current_step"] = step_name
        result = None

        try:
            if step_name == "reachability":
                result = step_reachability(client)
                if result["status"] == "FAIL":
                    ticket["step_results"].append(result)
                    completed += 1
                    log(f"  ✗ {result['note']} — stopping pipeline")
                    ticket["status"] = "Unreachable"
                    break

            elif step_name == "os_detect":
                result = step_os_detect(client, os_type)
                os_type = result.get("os_type", os_type)
                ticket["os_type"] = os_type

            elif step_name == "ssh_login":
                result = test_login(client)
                if result["status"] == "FAIL":
                    ticket["step_results"].append(result)
                    completed += 1
                    log(f"  ✗ {result['note']} — stopping pipeline")
                    ticket["status"] = "Failed"
                    break

            elif step_name == "service_check":
                result = check_services(client)

            elif step_name == "disk_check":
                result = check_disk(client)
                ticket["disk_results"] = result.get("disks", [])

            elif step_name == "retrigger":
                # Only retrigger if service_check didn't hard-fail
                svc_result = next((r for r in ticket["step_results"]
                                   if r["step"] == "service_check"), None)
                if svc_result and svc_result["status"] == "FAIL":
                    result = {"step": "retrigger", "status": "SKIP",
                              "note": "Skipped — service check failed"}
                else:
                    result = retrigger_backup(nw_server, client)

            elif step_name == "rdp_workorder":
                result = step_rdp_workorder(ticket)
                ticket["rdp_workorder"] = result.get("workorder", "")

            else:
                result = {"step": step_name, "status": "SKIP",
                          "note": f"Unknown step: {step_name}"}

        except Exception as e:
            result = {"step": step_name, "status": "ERROR",
                      "note": f"Unexpected error: {e}"}

        if result:
            ticket["step_results"].append(result)
            icon = {"PASS": "✓", "FAIL": "✗", "RED": "🔴", "SKIP": "—",
                    "MANUAL": "📋", "WARN": "⚠", "ERROR": "✗"}.get(result["status"], "•")
            log(f"  {icon} {result['note']}")
            completed += 1

    ticket["steps_done"]  = completed
    ticket["current_step"] = None

    # ── Determine final status ───────────────────────────────────────────
    if ticket["status"] not in ("Unreachable", "Failed"):
        has_fail     = any(r["status"] in ("FAIL","ERROR") for r in ticket["step_results"])
        has_red_disk = any(r["step"] == "disk_check" and r["status"] == "RED"
                          for r in ticket["step_results"])
        retrig_pass  = any(r["step"] == "retrigger" and r["status"] == "PASS"
                          for r in ticket["step_results"])
        is_windows   = os_type == "Windows"

        if is_windows:
            ticket["status"] = "Manual Required"
        elif has_fail:
            ticket["status"] = "Failed"
        elif has_red_disk and retrig_pass:
            ticket["status"] = "Partial"
        elif retrig_pass:
            ticket["status"] = "Remediated"
        else:
            ticket["status"] = "Partial"

    # ── AI writes close notes ────────────────────────────────────────────
    log("AI: Writing close notes...")
    ticket["close_notes"] = write_close_notes(ticket, ticket["step_results"])

    # ── Extract root cause for trend analysis ────────────────────────────
    svc_results = next((r for r in ticket["step_results"] if r["step"] == "service_check"), None)
    disk_result = next((r for r in ticket["step_results"] if r["step"] == "disk_check"), None)
    if svc_results:
        restarted = [s["service"] for s in svc_results.get("services", [])
                     if s.get("action") == "restarted"]
        if restarted:
            ticket["root_cause"] = f"Service stopped: {', '.join(restarted)}"
    if disk_result and disk_result["status"] == "RED" and not ticket.get("root_cause"):
        ticket["root_cause"] = "Insufficient disk space"
    if not ticket.get("root_cause"):
        ticket["root_cause"] = "Unknown — see close notes"

    ticket["updated"]      = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ticket["completed_at"] = datetime.now().isoformat()

    log(f"Pipeline complete — status: {ticket['status']}")
    return ticket
