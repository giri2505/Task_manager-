"""
core/linux.py — Linux client automation
All SSH operations using the service account configured in settings.
No parameters passed at runtime — everything read from config.
"""

import io
import os
import sys
import config


def _get_ssh_client(hostname: str):
    """
    Create and return a connected paramiko SSH client using config settings.
    Raises RuntimeError on failure.
    """
    try:
        import paramiko
    except ImportError:
        raise RuntimeError("paramiko not installed — run: pip install paramiko")

    cfg         = config.load()
    username    = cfg.get("linux_username", "svc_backup")
    auth_method = cfg.get("linux_auth_method", "password")
    password    = cfg.get("linux_password") or None
    key_path    = cfg.get("linux_key_path") or None
    key_text    = cfg.get("linux_key_text") or None
    timeout     = cfg.get("ssh_timeout_sec", 15)

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    connect_kw = dict(hostname=hostname, username=username, timeout=timeout)

    if auth_method == "password":
        if not password:
            raise RuntimeError("Linux password not configured — go to Settings")
        connect_kw.update(password=password, look_for_keys=False, allow_agent=False)

    elif auth_method == "key_file":
        if not key_path or not os.path.exists(key_path):
            raise RuntimeError(f"SSH key file not found: {key_path}")
        connect_kw.update(key_filename=key_path, look_for_keys=False, allow_agent=False)
        if password:
            connect_kw["passphrase"] = password

    elif auth_method == "key_text":
        if not key_text:
            raise RuntimeError("SSH key text not configured — go to Settings")
        pkey = _load_key_from_text(key_text, passphrase=password)
        connect_kw.update(pkey=pkey, look_for_keys=False, allow_agent=False)

    elif auth_method == "agent":
        connect_kw.update(allow_agent=True, look_for_keys=True)

    elif auth_method in ("pam", "ldap", "radius", "tacacs"):
        if not password:
            raise RuntimeError(f"{auth_method} auth requires a password — go to Settings")
        connect_kw.update(password=password, look_for_keys=False, allow_agent=False)

    else:
        raise RuntimeError(f"Unknown SSH auth method: {auth_method}")

    try:
        client.connect(**connect_kw)
        return client
    except paramiko.AuthenticationException:
        raise RuntimeError(f"SSH auth failed for {username}@{hostname} (method: {auth_method})")
    except Exception as e:
        raise RuntimeError(f"SSH connection to {hostname} failed: {e}")


def _load_key_from_text(key_text: str, passphrase: str = None):
    import paramiko
    buf = io.StringIO(key_text.strip())
    for loader in [paramiko.RSAKey, paramiko.Ed25519Key, paramiko.ECDSAKey, paramiko.DSSKey]:
        try:
            buf.seek(0)
            kw = {"file_obj": buf}
            if passphrase:
                kw["password"] = passphrase
            return loader.from_private_key(**kw)
        except Exception:
            continue
    raise RuntimeError("Cannot parse SSH private key — check format in Settings")


def run_command(hostname: str, command: str) -> tuple[str, str, int]:
    """
    Run a shell command on a Linux host.
    Returns (stdout, stderr, exit_code).
    """
    client = _get_ssh_client(hostname)
    try:
        _, stdout, stderr = client.exec_command(command, timeout=60)
        rc = stdout.channel.recv_exit_status()
        return stdout.read().decode().strip(), stderr.read().decode().strip(), rc
    finally:
        client.close()


# ─────────────────────────────────────────────────────────────────────────────
# Step: SSH Login test
# ─────────────────────────────────────────────────────────────────────────────

def test_login(hostname: str) -> dict:
    """Try to SSH in and run `hostname`. Returns step result dict."""
    try:
        stdout, _, rc = run_command(hostname, "hostname && id")
        if rc == 0:
            return {"step": "ssh_login", "status": "PASS",
                    "note": f"Logged in as {config.get('linux_username')} — host reports: {stdout.splitlines()[0]}"}
        return {"step": "ssh_login", "status": "FAIL", "note": f"hostname command failed (rc={rc})"}
    except RuntimeError as e:
        return {"step": "ssh_login", "status": "FAIL", "note": str(e)}


# ─────────────────────────────────────────────────────────────────────────────
# Step: Service check & restart
# ─────────────────────────────────────────────────────────────────────────────

def check_services(hostname: str) -> dict:
    """
    Check all configured Linux services. Restart any that are stopped.
    Returns step result dict with per-service detail.
    """
    services = config.get("linux_services", ["nsrexecd"])
    results  = []
    overall  = "PASS"

    for svc in services:
        try:
            # Check status
            stdout, _, rc = run_command(
                hostname,
                f"systemctl is-active {svc} 2>/dev/null || "
                f"service {svc} status 2>/dev/null | grep -iE 'running|active'"
            )
            is_running = rc == 0 or "active" in stdout.lower() or "running" in stdout.lower()

            if is_running:
                results.append({"service": svc, "state": "running", "action": "none"})
            else:
                # Attempt restart
                _, _, restart_rc = run_command(
                    hostname,
                    f"sudo systemctl restart {svc} 2>/dev/null || sudo service {svc} restart 2>/dev/null"
                )
                # Verify it's now running
                _, _, verify_rc = run_command(hostname, f"systemctl is-active {svc} 2>/dev/null")
                if verify_rc == 0 or restart_rc == 0:
                    results.append({"service": svc, "state": "restarted", "action": "restarted"})
                else:
                    results.append({"service": svc, "state": "restart_failed", "action": "restart_failed"})
                    overall = "FAIL"
        except RuntimeError as e:
            results.append({"service": svc, "state": "error", "action": "error", "error": str(e)})
            overall = "FAIL"

    restarted = [r["service"] for r in results if r["action"] == "restarted"]
    failed    = [r["service"] for r in results if r["action"] == "restart_failed"]
    note_parts = []
    if restarted: note_parts.append(f"Restarted: {', '.join(restarted)}")
    if failed:    note_parts.append(f"Restart FAILED: {', '.join(failed)}")
    if not note_parts: note_parts.append("All services running OK")

    return {
        "step":     "service_check",
        "status":   overall,
        "note":     " | ".join(note_parts),
        "services": results,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Step: Disk space check
# ─────────────────────────────────────────────────────────────────────────────

CHECK_PATHS = ["/", "/backup", "/nsr", "/tmp", "/var"]

def check_disk(hostname: str) -> dict:
    """
    Check disk space on Linux client. Flag RED if any path is below threshold.
    """
    min_gb = config.get("min_disk_gb", 10)
    try:
        stdout, _, rc = run_command(hostname, "df -BG --output=target,avail,pcent 2>/dev/null || df -BG")
        disks   = []
        red     = []

        for line in stdout.splitlines()[1:]:
            parts = line.split()
            if len(parts) < 3:
                continue
            mountpoint = parts[0]
            if not any(mountpoint == p or mountpoint.startswith(p + "/") for p in CHECK_PATHS):
                continue
            try:
                avail_gb = float(parts[1].replace("G", "").replace("M", ""))
                if "M" in parts[1]: avail_gb /= 1024
                pct_used = parts[2]
                flag     = "RED" if avail_gb < min_gb else "OK"
                disks.append({"path": mountpoint, "free_gb": round(avail_gb, 1),
                               "pct_used": pct_used, "flag": flag})
                if flag == "RED":
                    red.append(f"{mountpoint} ({avail_gb:.1f} GB free)")
            except (ValueError, IndexError):
                continue

        if red:
            return {"step": "disk_check", "status": "RED",
                    "note": f"Low disk space: {', '.join(red)} — manual cleanup required",
                    "disks": disks}
        if disks:
            return {"step": "disk_check", "status": "PASS",
                    "note": "Sufficient disk space on all checked paths", "disks": disks}
        return {"step": "disk_check", "status": "WARN",
                "note": "No matching mount points found", "disks": []}

    except RuntimeError as e:
        return {"step": "disk_check", "status": "FAIL", "note": str(e), "disks": []}


# ─────────────────────────────────────────────────────────────────────────────
# Step: Retrigger backup on NetWorker server
# ─────────────────────────────────────────────────────────────────────────────

def retrigger_backup(nw_server: str, client: str) -> dict:
    """
    SSH into the NetWorker server and retrigger the backup for the failed client.
    Command is read from config — set in Settings → Retrigger Command.
    """
    cmd_template = config.get("nw_retrigger_cmd", "")

    if not cmd_template:
        return {
            "step":   "retrigger",
            "status": "SKIP",
            "note":   "Retrigger command not configured — go to Settings and set the NetWorker command",
        }

    cmd = cmd_template.format(nw_server=nw_server, client=client)

    try:
        stdout, stderr, rc = run_command(nw_server, cmd)
        if rc == 0:
            return {"step": "retrigger", "status": "PASS",
                    "note": f"Command succeeded on {nw_server}",
                    "command": cmd, "output": stdout[:300]}
        else:
            return {"step": "retrigger", "status": "FAIL",
                    "note": f"Command failed (rc={rc}): {stderr[:200] or stdout[:200]}",
                    "command": cmd}
    except RuntimeError as e:
        return {"step": "retrigger", "status": "FAIL", "note": str(e), "command": cmd}
