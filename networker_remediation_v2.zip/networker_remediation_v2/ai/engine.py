"""
ai/engine.py — Azure OpenAI integration
Handles:
  1. Ticket parsing  — extract server, client, error details from free text
  2. Step planning   — AI decides which steps to run and in what order
  3. Close notes     — AI writes the final close note from step results
  4. Root cause      — AI identifies recurring patterns across tickets
"""

import json
import urllib.request
import urllib.error
from datetime import datetime
import config


# ─────────────────────────────────────────────────────────────────────────────
# Low-level Azure OpenAI call — uses only stdlib (no openai package needed)
# ─────────────────────────────────────────────────────────────────────────────

def _call_openai(messages: list[dict], temperature: float = 0.2,
                 max_tokens: int = 1500, json_mode: bool = False) -> str:
    """
    Call Azure OpenAI chat completions endpoint.
    Returns the assistant message content string.
    Raises RuntimeError on failure.
    """
    cfg = config.load()
    endpoint   = cfg.get("azure_openai_endpoint", "").rstrip("/")
    api_key    = cfg.get("azure_openai_api_key", "")
    deployment = cfg.get("azure_openai_deployment", "gpt-4o")
    api_ver    = cfg.get("azure_openai_api_version", "2024-02-01")

    if not endpoint or not api_key:
        raise RuntimeError("Azure OpenAI not configured — go to Settings and add your endpoint + API key.")

    url = f"{endpoint}/openai/deployments/{deployment}/chat/completions?api-version={api_ver}"

    body = {
        "messages":    messages,
        "temperature": temperature,
        "max_tokens":  max_tokens,
    }
    if json_mode:
        body["response_format"] = {"type": "json_object"}

    payload = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=payload,
        headers={
            "Content-Type":  "application/json",
            "api-key":       api_key,
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            return result["choices"][0]["message"]["content"]
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Azure OpenAI HTTP {e.code}: {body[:400]}")
    except Exception as e:
        raise RuntimeError(f"Azure OpenAI call failed: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# 1. Ticket Parsing
# ─────────────────────────────────────────────────────────────────────────────

PARSE_SYSTEM = """You are an expert NetWorker backup systems engineer assistant.
Your job is to extract structured information from ServiceNow backup failure ticket text.

Extract exactly these fields and return ONLY a JSON object, no other text:
{
  "ticket_id":   "INC number or ticket reference, e.g. INC0098721",
  "nw_server":   "NetWorker server hostname (the backup SERVER, not the client)",
  "client":      "The backup CLIENT hostname that failed",
  "os_type":     "Windows or Linux — infer from hostname patterns or explicit mentions",
  "error_code":  "Any error code mentioned, e.g. nsrexecd not running, 23:5-23-2",
  "error_summary": "One sentence describing what failed",
  "backup_group": "Backup group or policy name if mentioned, else null",
  "last_success": "Last successful backup time if mentioned, else null",
  "priority":    "P1/P2/P3/P4 if mentioned, else P3",
  "confidence":  "high/medium/low — how confident you are in the extraction"
}

Rules:
- nw_server is the NetWorker SERVER (often has 'nw', 'backup', 'bkp', 'networker' in the name)
- client is the machine that FAILED to back up (application server, DB server, etc.)
- If OS cannot be determined, guess from hostname: win/srv/dc/sql → Windows, else Linux
- Never leave nw_server or client as null — make your best guess and set confidence=low
"""

def parse_ticket(raw_text: str, structured_fields: dict = None) -> dict:
    """
    Use GPT-4o to parse a ticket from free text (and optional structured fields).
    Returns a dict with ticket fields + ai_parse_notes.
    """
    context = ""
    if structured_fields:
        context = "Structured fields from the ticket form:\n"
        for k, v in structured_fields.items():
            if v:
                context += f"  {k}: {v}\n"
        context += "\nFree text description / work notes:\n"

    user_msg = context + raw_text

    try:
        raw = _call_openai(
            messages=[
                {"role": "system",  "content": PARSE_SYSTEM},
                {"role": "user",    "content": user_msg},
            ],
            temperature=0.1,
            max_tokens=600,
            json_mode=True,
        )
        parsed = json.loads(raw)
        parsed["ai_parsed"] = True
        parsed["ai_parse_notes"] = f"Parsed by GPT-4o at {datetime.now().strftime('%H:%M:%S')}"
        return parsed
    except Exception as e:
        # Fallback: return empty structure with error note
        return {
            "ticket_id":     structured_fields.get("number", "UNKNOWN") if structured_fields else "UNKNOWN",
            "nw_server":     structured_fields.get("nw_server", "") if structured_fields else "",
            "client":        structured_fields.get("client", "") if structured_fields else "",
            "os_type":       "Unknown",
            "error_code":    "",
            "error_summary": raw_text[:200],
            "priority":      "P3",
            "confidence":    "low",
            "ai_parsed":     False,
            "ai_parse_notes": f"AI parse failed: {e}. Please verify fields manually.",
        }


# ─────────────────────────────────────────────────────────────────────────────
# 2. Step Planning — AI decides what to do
# ─────────────────────────────────────────────────────────────────────────────

PLAN_SYSTEM = """You are an intelligent NetWorker backup automation engine.
Given a parsed backup failure ticket, you must decide which remediation steps to execute and in what order.

Available steps:
  reachability   — Ping the client to check if it is online
  os_detect      — Detect Windows vs Linux via port probe
  ssh_login      — SSH into Linux client using service account
  service_check  — Check if nsrexecd and other backup services are running; restart if stopped
  disk_check     — Check available disk space on the client
  retrigger      — Re-run the backup job on the NetWorker server
  rdp_workorder  — (Windows only) Generate a manual RDP work order for the engineer

Rules:
- ALWAYS start with reachability
- If os_type is already known as Linux, skip os_detect
- If os_type is Windows: only run reachability + rdp_workorder (no SSH)
- If the error mentions "nsrexecd not running" or "client not responding" — prioritize service_check
- If the error mentions "disk full" or "no space" — prioritize disk_check BEFORE retrigger
- If the error is unclear — run all Linux steps in order
- Always end with retrigger (Linux) or rdp_workorder (Windows)

Return ONLY a JSON object:
{
  "steps": ["reachability", "ssh_login", "service_check", "disk_check", "retrigger"],
  "rationale": "One sentence explaining your decision",
  "risk_level": "low/medium/high",
  "estimated_duration_mins": 3
}
"""

def plan_steps(ticket: dict) -> dict:
    """
    Ask GPT-4o to decide which steps to run for this ticket.
    Returns {"steps": [...], "rationale": "...", "risk_level": "...", ...}
    """
    ticket_summary = json.dumps({
        k: v for k, v in ticket.items()
        if k in ("ticket_id","nw_server","client","os_type",
                 "error_code","error_summary","priority","confidence")
    }, indent=2)

    try:
        raw = _call_openai(
            messages=[
                {"role": "system", "content": PLAN_SYSTEM},
                {"role": "user",   "content": f"Ticket:\n{ticket_summary}"},
            ],
            temperature=0.1,
            max_tokens=400,
            json_mode=True,
        )
        plan = json.loads(raw)
        plan["ai_planned"] = True
        return plan
    except Exception as e:
        # Safe fallback plan
        os_type = ticket.get("os_type", "Unknown")
        if os_type == "Windows":
            steps = ["reachability", "rdp_workorder"]
        else:
            steps = ["reachability", "os_detect", "ssh_login",
                     "service_check", "disk_check", "retrigger"]
        return {
            "steps":                  steps,
            "rationale":              f"Default plan used (AI planning failed: {e})",
            "risk_level":             "low",
            "estimated_duration_mins": 5,
            "ai_planned":             False,
        }


# ─────────────────────────────────────────────────────────────────────────────
# 3. Close Notes — AI writes the resolution summary
# ─────────────────────────────────────────────────────────────────────────────

CLOSE_SYSTEM = """You are a senior NetWorker backup engineer writing a ServiceNow close note.
Write a professional, clear, concise close note for this backup failure ticket.

The close note must include:
1. What the root cause was
2. What automated actions were taken (services restarted, disk issues found, etc.)
3. Whether the backup was successfully retriggered
4. Any manual follow-up actions required
5. A recommendation to prevent recurrence

Tone: professional, factual, no jargon, suitable for a senior engineer audience.
Length: 150-250 words. Use plain paragraphs, no bullet points.
"""

def write_close_notes(ticket: dict, step_results: list[dict]) -> str:
    """
    Ask GPT-4o to write the close note from step execution results.
    Returns a formatted string.
    """
    context = f"""
Ticket: {ticket.get('ticket_id')}
Client: {ticket.get('client')}
NetWorker Server: {ticket.get('nw_server')}
OS: {ticket.get('os_type')}
Original error: {ticket.get('error_summary', 'Backup failure')}

Automated steps executed:
"""
    for step in step_results:
        status = step.get("status", "unknown")
        note   = step.get("note", "")
        context += f"  [{step.get('step')}] {status.upper()} — {note}\n"

    try:
        notes = _call_openai(
            messages=[
                {"role": "system", "content": CLOSE_SYSTEM},
                {"role": "user",   "content": context},
            ],
            temperature=0.4,
            max_tokens=500,
        )
        return notes.strip()
    except Exception as e:
        # Fallback to structured text
        lines = [
            f"=== Close Notes — {ticket.get('ticket_id')} ===",
            f"Client: {ticket.get('client')}  |  Server: {ticket.get('nw_server')}",
            f"Original error: {ticket.get('error_summary', 'Backup failure')}",
            "",
            "Steps executed:",
        ]
        for step in step_results:
            lines.append(f"  [{step.get('step')}] {step.get('status','?').upper()} — {step.get('note','')}")
        lines.append(f"\n(AI close note generation failed: {e})")
        return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# 4. Root Cause Analysis — AI looks across multiple tickets for patterns
# ─────────────────────────────────────────────────────────────────────────────

RCA_SYSTEM = """You are a NetWorker backup reliability engineer.
Analyse the provided list of recent backup failure tickets and identify:
1. The most common root causes
2. Which clients or servers fail most often
3. Patterns (time of day, day of week, specific error types)
4. Concrete recommendations to reduce ticket volume

Return ONLY a JSON object:
{
  "top_causes": [{"cause": "...", "count": N, "recommendation": "..."}],
  "problem_clients": [{"client": "...", "failure_count": N, "likely_cause": "..."}],
  "problem_servers": [{"server": "...", "failure_count": N}],
  "patterns": ["..."],
  "priority_actions": ["..."],
  "predicted_reduction_pct": N
}
"""

def analyse_trends(tickets: list[dict]) -> dict:
    """
    Run root cause analysis across all completed tickets.
    Returns structured insights.
    """
    if not tickets:
        return {"error": "No tickets to analyse"}

    # Summarise tickets for the prompt
    summaries = []
    for t in tickets[-50:]:   # last 50 tickets
        summaries.append({
            "id":            t.get("ticket_id"),
            "client":        t.get("client"),
            "server":        t.get("nw_server"),
            "os":            t.get("os_type"),
            "error":         t.get("error_summary"),
            "root_cause":    t.get("root_cause"),
            "services_fixed": [s["service"] for s in t.get("step5_services", [])
                               if s.get("action") == "restarted"],
            "disk_low":      t.get("step6_status") == "RED",
            "resolved":      t.get("status") in ("Remediated", "Partial"),
            "date":          t.get("updated", ""),
        })

    try:
        raw = _call_openai(
            messages=[
                {"role": "system", "content": RCA_SYSTEM},
                {"role": "user",   "content": f"Tickets:\n{json.dumps(summaries, indent=2)}"},
            ],
            temperature=0.3,
            max_tokens=1000,
            json_mode=True,
        )
        result = json.loads(raw)
        result["analysed_at"]    = datetime.now().isoformat()
        result["tickets_analysed"] = len(summaries)
        return result
    except Exception as e:
        return {"error": str(e), "analysed_at": datetime.now().isoformat()}


# ─────────────────────────────────────────────────────────────────────────────
# 5. Windows RDP Work Order
# ─────────────────────────────────────────────────────────────────────────────

RDP_SYSTEM = """You are a NetWorker backup engineer creating a manual work order for an engineer who will RDP into a Windows server.
The automated system cannot run commands on Windows (RDP-only access with PAM account).

Write a clear, step-by-step work order that the engineer should follow after RDP-ing in.
Include:
- Exact service names to check in services.msc
- Exact PowerShell commands to run to check disk space
- What to look for in Event Viewer
- How to manually retrigger the backup if services are healthy

Format as numbered steps. Be specific and actionable.
"""

def generate_rdp_workorder(ticket: dict) -> str:
    """Generate a step-by-step RDP work order for Windows tickets."""
    context = f"""
Windows backup failure ticket:
Client: {ticket.get('client')}
NetWorker Server: {ticket.get('nw_server')}
Error: {ticket.get('error_summary', 'Backup failure')}
Error code: {ticket.get('error_code', 'unknown')}
"""
    try:
        return _call_openai(
            messages=[
                {"role": "system", "content": RDP_SYSTEM},
                {"role": "user",   "content": context},
            ],
            temperature=0.3,
            max_tokens=600,
        ).strip()
    except Exception as e:
        cfg = config.load()
        domain = cfg.get("windows_rdp_domain", "CORP")
        return f"""Windows RDP Work Order — {ticket.get('ticket_id')}
Client: {ticket.get('client')}
NetWorker Server: {ticket.get('nw_server')}

1. RDP into {ticket.get('client')} using your PAM account ({domain}\\<your_username>)
2. Open services.msc → check 'NetWorker Remote Exec Service' and 'Legato NetWorker' are Running
3. If stopped: right-click → Start
4. Open PowerShell as Admin → run: Get-PSDrive -PSProvider FileSystem | Select Name,@{{N='FreeGB';E={{[math]::Round($_.Free/1GB,1)}}}}
5. Check for drives below {cfg.get('min_disk_gb', 10)} GB free — clean up if needed
6. Open Event Viewer → Windows Logs → Application → filter for NetWorker errors
7. To retrigger: open NetWorker Management Console on {ticket.get('nw_server')} → Monitoring → manually start the failed group
8. Update ticket with findings.

(AI work order generation failed: {e})"""
