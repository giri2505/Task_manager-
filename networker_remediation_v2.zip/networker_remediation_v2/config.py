"""
config.py — Central application configuration
All settings live here or in config.json (written by the dashboard Settings page).
The application runs as a persistent server. No CLI parameters needed.
"""

import json
import os

CONFIG_FILE = os.path.join(os.path.dirname(__file__), 'config.json')

DEFAULTS = {
    # ── Azure OpenAI ─────────────────────────────────────────────────────
    "azure_openai_endpoint":    "",          # https://YOUR-RESOURCE.openai.azure.com/
    "azure_openai_api_key":     "",
    "azure_openai_deployment":  "gpt-4o",   # your deployment name
    "azure_openai_api_version": "2024-02-01",

    # ── Linux SSH service account ─────────────────────────────────────────
    "linux_username":    "svc_backup",
    "linux_auth_method": "password",        # password | key_file | key_text | agent
    "linux_password":    "",
    "linux_key_path":    "",
    "linux_key_text":    "",

    # ── Windows — RDP only, no automated remote execution ─────────────────
    # Windows tickets get: reachability check + AI-generated RDP work order
    "windows_rdp_domain": "",               # CORP  (prepended to username in instructions)

    # ── NetWorker ─────────────────────────────────────────────────────────
    "nw_retrigger_cmd":  "",                # e.g. nsrinfo -s {nw_server} -c {client} -v
    #                                         Leave blank → AI will suggest the command

    # ── Services to verify on Linux clients ───────────────────────────────
    "linux_services": ["nsrexecd"],         # confirm and add more
    "windows_services": [],                 # not auto-checked (RDP only)

    # ── Automation thresholds ─────────────────────────────────────────────
    "min_disk_gb":          10,
    "ping_retries":         3,
    "ping_timeout_sec":     3,
    "ssh_timeout_sec":      15,

    # ── ServiceNow polling (optional future integration) ──────────────────
    "snow_instance":  "",                   # e.g. yourcompany.service-now.com
    "snow_username":  "",
    "snow_password":  "",
    "snow_query":     "active=true^category=backup^state=1",

    # ── Application server ────────────────────────────────────────────────
    "server_host":  "0.0.0.0",
    "server_port":  5050,
    "auto_run_new": False,                  # auto-trigger pipeline on import
}


def load() -> dict:
    cfg = dict(DEFAULTS)
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE) as f:
                saved = json.load(f)
            cfg.update(saved)
        except Exception:
            pass
    return cfg


def save(updates: dict):
    cfg = load()
    cfg.update(updates)
    with open(CONFIG_FILE, 'w') as f:
        json.dump(cfg, f, indent=2)


def get(key: str, default=None):
    return load().get(key, default)
