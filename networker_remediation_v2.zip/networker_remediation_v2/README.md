# NetWorker Backup Remediation System
## Setup & Run

### 1. Install dependencies
```bash
pip install flask flask-cors paramiko
```

### 2. Start the application (no parameters needed)
```bash
python app.py
```

### 3. Open the dashboard
```
http://YOUR-SERVER-IP:5050
```

### 4. First-time setup (in the dashboard Settings page)
1. **Azure OpenAI** — enter your endpoint, API key, deployment name (gpt-4o)
2. **Linux SSH** — enter service account username + password (or key)
3. **NetWorker** — enter the retrigger command and service names to check
4. Click **Save Settings** → **Test AI Connection** → **Test SSH Connection**

---

## How it works

```
ServiceNow CSV export
        ↓
   Import CSV (dashboard)
        ↓
   GPT-4o parses each ticket
   (extracts server, client, error, OS)
        ↓
   GPT-4o plans remediation steps
   (decides what to run based on error type)
        ↓
   ┌─── Linux ───────────────────────────┐
   │  1. Ping client                      │
   │  2. SSH in with service account      │
   │  3. Check & restart services         │
   │  4. Check disk space                 │
   │  5. Retrigger backup on NW server    │
   └──────────────────────────────────────┘
   ┌─── Windows ──────────────────────────┐
   │  1. Ping client                      │
   │  2. GPT-4o writes RDP work order     │
   │     (manual engineer action needed)  │
   └──────────────────────────────────────┘
        ↓
   GPT-4o writes close notes
        ↓
   Analytics & Root Cause Analysis
   (AI identifies patterns, recommends fixes)
```

## Running as a service (Linux server)

```bash
# Create a systemd service
cat > /etc/systemd/system/nw-remediation.service << EOF
[Unit]
Description=NetWorker Backup Remediation System
After=network.target

[Service]
Type=simple
User=svc_backup
WorkingDirectory=/opt/nw_remediation
ExecStart=/usr/bin/python3 /opt/nw_remediation/app.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable nw-remediation
systemctl start nw-remediation
```

## File structure
```
nw_app/
├── app.py              ← Application entry point (run this)
├── config.py           ← Configuration management
├── dashboard.html      ← Web UI (served by app.py)
├── requirements.txt
├── config.json         ← Created on first settings save
├── tickets.json        ← Ticket data (auto-created)
├── ai/
│   └── engine.py       ← Azure OpenAI integration
└── core/
    ├── linux.py        ← SSH automation for Linux clients
    └── pipeline.py     ← AI-driven orchestration engine
```
