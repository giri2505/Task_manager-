"""
AI Analysis Module — NetWorker Remediation Intelligence Layer
=============================================================
Uses Claude (Anthropic API) to provide:
  1. Pre-remediation ticket triage (risk scoring, predicted root cause)
  2. Post-remediation RCA (root cause analysis) with remediation narrative
  3. Anomaly detection across ticket batches (pattern analysis)
  4. Smart close notes with natural language summary
  5. Remediation recommendation (next actions if automation fails)

API key is read from environment: ANTHROPIC_API_KEY
Falls back gracefully if key not set — all AI features become no-ops.
"""

import json
import os
import re
import time
from datetime import datetime
from typing import Optional

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
MODEL = "claude-sonnet-4-20250514"
API_URL = "https://api.anthropic.com/v1/messages"

# ─────────────────────────────────────────────────────────────────────────────
# Core API call
# ─────────────────────────────────────────────────────────────────────────────

def _call_claude(system: str, user: str, max_tokens: int = 800) -> Optional[str]:
    """Call Claude API. Returns text or None on any failure."""
    if not ANTHROPIC_API_KEY:
        return None
    try:
        import urllib.request
        payload = json.dumps({
            "model": MODEL,
            "max_tokens": max_tokens,
            "system": system,
            "messages": [{"role": "user", "content": user}]
        }).encode()
        req = urllib.request.Request(
            API_URL,
            data=payload,
            headers={
                "Content-Type": "application/json",
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01"
            }
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read())
            return data["content"][0]["text"].strip()
    except Exception as e:
        print(f"[AI] Claude API call failed: {e}")
        return None


def _call_claude_json(system: str, user: str, max_tokens: int = 800) -> Optional[dict]:
    """Call Claude and parse JSON response."""
    raw = _call_claude(system, user + "\n\nRespond with ONLY valid JSON. No markdown, no preamble.", max_tokens)
    if not raw:
        return None
    try:
        clean = re.sub(r'^```json\s*|^```\s*|```$', '', raw.strip(), flags=re.MULTILINE).strip()
        return json.loads(clean)
    except Exception:
        return None


# ─────────────────────────────────────────────────────────────────────────────
# 1. Pre-Remediation Triage
# ─────────────────────────────────────────────────────────────────────────────

TRIAGE_SYSTEM = """You are an expert NetWorker backup automation engineer. 
Analyse ticket data and return a JSON triage assessment. Be concise and precise.
Response must be valid JSON only."""

def triage_ticket(ticket: dict) -> dict:
    """
    Pre-remediation AI triage. Returns enriched ticket with:
      ai_risk_score    : 1-10 (10 = highest risk of failure)
      ai_predicted_cause: likely root cause string
      ai_priority      : Critical | High | Medium | Low
      ai_triage_note   : 1-2 sentence summary
    """
    result = {
        "ai_risk_score": None,
        "ai_predicted_cause": None,
        "ai_priority": None,
        "ai_triage_note": None,
        "ai_triage_time": datetime.now().strftime("%H:%M:%S"),
    }

    user = f"""Triage this NetWorker backup failure ticket:
Ticket ID  : {ticket.get('ticket_id')}
NW Server  : {ticket.get('nw_server')}
Client     : {ticket.get('client')}
OS         : {ticket.get('os_type', 'Unknown')}
Description: {ticket.get('description', 'No description')}
Error msg  : {ticket.get('error_message', 'None')}

Return JSON: {{
  "risk_score": <1-10>,
  "predicted_cause": "<most likely root cause in 8 words or less>",
  "priority": "<Critical|High|Medium|Low>",
  "triage_note": "<1 sentence actionable insight>"
}}"""

    resp = _call_claude_json(TRIAGE_SYSTEM, user)
    if resp:
        result["ai_risk_score"] = resp.get("risk_score")
        result["ai_predicted_cause"] = resp.get("predicted_cause")
        result["ai_priority"] = resp.get("priority")
        result["ai_triage_note"] = resp.get("triage_note")

    ticket.update(result)
    return ticket


# ─────────────────────────────────────────────────────────────────────────────
# 2. Post-Remediation Root Cause Analysis
# ─────────────────────────────────────────────────────────────────────────────

RCA_SYSTEM = """You are a senior backup infrastructure engineer writing a root cause analysis (RCA) report. 
Be technical, precise, and actionable. Output JSON only."""

def generate_rca(ticket: dict) -> dict:
    """
    Post-remediation RCA. Returns enriched ticket with:
      ai_root_cause      : confirmed root cause
      ai_remediation_summary: what was done
      ai_preventive_actions : list of 2-3 preventive measures
      ai_confidence       : High | Medium | Low
    """
    services_info = ""
    for svc in ticket.get("step5_services", []):
        services_info += f"  - {svc['service']}: {svc['state']} (action: {svc['action']})\n"

    disk_info = ""
    for d in ticket.get("step6_disk", []):
        disk_info += f"  - {d['path']}: {d['detail']} [{d.get('flag','OK')}]\n"

    user = f"""Perform RCA for this completed NetWorker backup remediation:

Ticket: {ticket.get('ticket_id')} | Client: {ticket.get('client')} | OS: {ticket.get('os_type')}

Step Results:
  Reachability : {ticket.get('step2_status')} — {ticket.get('step2_note','')}
  OS Detection : {ticket.get('step3_status')} — {ticket.get('step3_note','')}
  Login        : {ticket.get('step4_status')} — {ticket.get('step4_note','')}
  Services     : {ticket.get('step5_status')} — {ticket.get('step5_note','')}
{services_info}  Disk Space   : {ticket.get('step6_status')} — {ticket.get('step6_note','')}
{disk_info}  Backup Retrigger: {ticket.get('step7_status')} — {ticket.get('step7_note','')}

Return JSON: {{
  "root_cause": "<confirmed root cause in ≤12 words>",
  "remediation_summary": "<what automation did to fix it, 1-2 sentences>",
  "preventive_actions": ["<action 1>", "<action 2>", "<action 3>"],
  "confidence": "<High|Medium|Low>",
  "requires_manual_review": <true|false>
}}"""

    result = {
        "ai_root_cause": None,
        "ai_remediation_summary": None,
        "ai_preventive_actions": [],
        "ai_confidence": None,
        "ai_requires_manual_review": False,
        "ai_rca_time": datetime.now().strftime("%H:%M:%S"),
    }

    resp = _call_claude_json(RCA_SYSTEM, user)
    if resp:
        result["ai_root_cause"] = resp.get("root_cause")
        result["ai_remediation_summary"] = resp.get("remediation_summary")
        result["ai_preventive_actions"] = resp.get("preventive_actions", [])
        result["ai_confidence"] = resp.get("confidence")
        result["ai_requires_manual_review"] = resp.get("requires_manual_review", False)

    ticket.update(result)
    return ticket


# ─────────────────────────────────────────────────────────────────────────────
# 3. Batch Anomaly / Pattern Detection
# ─────────────────────────────────────────────────────────────────────────────

PATTERN_SYSTEM = """You are a NetWorker infrastructure analyst detecting patterns in backup failure data. 
Return JSON only. Be concise."""

def detect_patterns(tickets: list[dict]) -> dict:
    """
    Analyse all tickets for patterns/anomalies. Returns:
      patterns      : list of detected pattern objects
      systemic_risk : High | Medium | Low
      summary       : executive summary paragraph
    """
    if not tickets:
        return {}

    # Build compact summary for LLM
    rows = []
    for t in tickets:
        rows.append({
            "id": t.get("ticket_id"),
            "client": t.get("client"),
            "os": t.get("os_type"),
            "status": t.get("status"),
            "step2": t.get("step2_status"),
            "step4": t.get("step4_status"),
            "step5": t.get("step5_status"),
            "step5_note": t.get("step5_note", ""),
            "step6": t.get("step6_status"),
            "step7": t.get("step7_status"),
            "cause": t.get("ai_predicted_cause", ""),
        })

    user = f"""Analyse these {len(tickets)} NetWorker backup tickets for patterns:

{json.dumps(rows, indent=2)}

Return JSON:
{{
  "patterns": [
    {{
      "pattern_type": "<Service Outage|Disk Space|Auth Failure|Network|OS-Specific|Other>",
      "affected_count": <int>,
      "description": "<pattern description in ≤15 words>",
      "affected_tickets": ["<ticket_id>", ...]
    }}
  ],
  "systemic_risk": "<High|Medium|Low>",
  "summary": "<2-3 sentence executive summary of the batch>"
}}"""

    resp = _call_claude_json(PATTERN_SYSTEM, user, max_tokens=1000)
    if not resp:
        return {
            "patterns": [],
            "systemic_risk": "Unknown",
            "summary": "AI pattern analysis unavailable.",
        }
    return resp


# ─────────────────────────────────────────────────────────────────────────────
# 4. AI-Enhanced Close Notes
# ─────────────────────────────────────────────────────────────────────────────

CLOSE_NOTES_SYSTEM = """You are writing close notes for a ServiceNow backup incident ticket.
Write professional, concise close notes that a NOC engineer would approve.
Output JSON only."""

def generate_ai_close_notes(ticket: dict) -> str:
    """Generate natural-language close notes paragraph for ServiceNow."""
    user = f"""Write close notes for this backup incident:

Ticket: {ticket.get('ticket_id')} | Client: {ticket.get('client')} | OS: {ticket.get('os_type')}
Root cause: {ticket.get('ai_root_cause', 'Under investigation')}
Services affected: {ticket.get('step5_note', 'N/A')}
Disk status: {ticket.get('step6_note', 'N/A')}
Backup retrigger: {ticket.get('step7_status')} — {ticket.get('step7_note', '')}
Preventive actions: {', '.join(ticket.get('ai_preventive_actions', []))}

Return JSON: {{
  "close_notes_paragraph": "<professional close notes in 3-5 sentences>",
  "resolution_code": "<Resolved|Partially Resolved|Escalated|Monitoring>",
  "kb_article_suggestion": "<brief suggestion for KB article title if applicable, else null>"
}}"""

    resp = _call_claude_json(CLOSE_NOTES_SYSTEM, user)
    if resp:
        return resp.get("close_notes_paragraph", "")
    return ""


# ─────────────────────────────────────────────────────────────────────────────
# 5. Failure Recommendation (when automation fails)
# ─────────────────────────────────────────────────────────────────────────────

RECO_SYSTEM = """You are a senior NetWorker engineer advising L2 support on manual remediation steps.
Be specific, ordered, and actionable. Output JSON only."""

def recommend_manual_steps(ticket: dict) -> list[str]:
    """
    When automation fails, suggest manual investigation steps.
    Returns ordered list of action strings.
    """
    failed_step = None
    for step in ["step2", "step4", "step5", "step7"]:
        if ticket.get(f"{step}_status") == "FAIL":
            failed_step = step
            break

    if not failed_step:
        return []

    step_names = {
        "step2": "reachability/ping",
        "step4": "service account login",
        "step5": "service check/restart",
        "step7": "backup retrigger"
    }

    user = f"""Automation failed at step: {step_names.get(failed_step, failed_step)}
Error: {ticket.get(f'{failed_step}_note', 'Unknown')}
Client: {ticket.get('client')} | OS: {ticket.get('os_type')}

Provide 4-5 specific manual troubleshooting steps for an L2 engineer.
Return JSON: {{"steps": ["<step 1>", "<step 2>", ...]}}"""

    resp = _call_claude_json(RECO_SYSTEM, user)
    if resp:
        return resp.get("steps", [])
    return []
