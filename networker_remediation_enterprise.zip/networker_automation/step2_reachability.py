"""
Step 2: Reachability Check
Checks if the backup client is reachable via ICMP ping.
Usage: python step2_reachability.py --client app-srv-42.corp.com
       python step2_reachability.py --file parsed_tickets.json
"""

import argparse
import json
import platform
import subprocess
import sys


def ping_host(hostname: str, retries: int = 3, timeout: int = 3) -> bool:
    """
    Ping a host. Returns True if reachable.
    Works on both Windows and Linux.
    """
    os_name = platform.system().lower()

    for attempt in range(1, retries + 1):
        if os_name == 'windows':
            cmd = ['ping', '-n', '1', '-w', str(timeout * 1000), hostname]
        else:
            cmd = ['ping', '-c', '1', '-W', str(timeout), hostname]

        try:
            result = subprocess.run(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=timeout + 2
            )
            if result.returncode == 0:
                print(f"[STEP 2] ✓ {hostname} is REACHABLE (attempt {attempt})")
                return True
            else:
                print(f"[STEP 2] ✗ Attempt {attempt}/{retries}: {hostname} did not respond")
        except subprocess.TimeoutExpired:
            print(f"[STEP 2] ✗ Attempt {attempt}/{retries}: Ping timed out for {hostname}")
        except FileNotFoundError:
            print("[STEP 2] ERROR: 'ping' command not found on this system.")
            sys.exit(1)

    print(f"[STEP 2] ✗ {hostname} is UNREACHABLE after {retries} attempts — STOP")
    return False


def check_tickets(tickets: list[dict]) -> list[dict]:
    """Run reachability check on all tickets, tag each with 'reachable' bool."""
    for t in tickets:
        client = t.get('client', '')
        reachable = ping_host(client)
        t['reachable'] = reachable
        t['step2_status'] = 'PASS' if reachable else 'FAIL'
        t['step2_note'] = '' if reachable else f"Host {client} unreachable — ICMP timeout after 3 retries"

    reachable_count = sum(1 for t in tickets if t['reachable'])
    print(f"\n[STEP 2] Summary: {reachable_count}/{len(tickets)} clients reachable")
    return tickets


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Step 2: Reachability check')
    parser.add_argument('--client',  help='Single client hostname to check')
    parser.add_argument('--file',    help='Parsed tickets JSON (from step1)', default='parsed_tickets.json')
    parser.add_argument('--output',  help='Output JSON file', default='parsed_tickets.json')
    parser.add_argument('--retries', type=int, default=3)
    parser.add_argument('--timeout', type=int, default=3, help='Timeout per ping in seconds')
    args = parser.parse_args()

    if args.client:
        result = ping_host(args.client, args.retries, args.timeout)
        sys.exit(0 if result else 1)

    with open(args.file) as f:
        tickets = json.load(f)

    tickets = check_tickets(tickets)

    with open(args.output, 'w') as f:
        json.dump(tickets, f, indent=2)
    print(f"[STEP 2] Updated tickets saved to {args.output}")
