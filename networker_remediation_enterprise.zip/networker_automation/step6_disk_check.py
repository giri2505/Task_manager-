"""
Step 6: Disk Space Check
Checks available disk space on the client.
Flags RED if free space is below the threshold (default 10 GB).

Usage: python step6_disk_check.py --client app-srv-42 --os Linux --user svc_backup --key ~/.ssh/id_rsa
       python step6_disk_check.py --file parsed_tickets.json --user svc_backup --key ~/.ssh/id_rsa

Dependencies: pip install paramiko pywinrm
"""

import argparse
import json
import sys
from step4_login import ssh_login, winrm_login, run_ssh_command, run_winrm_command


# Minimum free space required (in GB). Anything below this is flagged RED.
MIN_FREE_GB = 10.0

# Paths to check on Linux (add backup mount points as needed)
LINUX_CHECK_PATHS = ['/', '/backup', '/nsr', '/tmp']

# Drives to check on Windows (add backup drives as needed)
WINDOWS_CHECK_DRIVES = ['C:', 'D:', 'E:']


def check_linux_disk(conn) -> list[dict]:
    """Run df -BG and parse results for configured paths."""
    stdout, stderr, rc = run_ssh_command(conn, "df -BG --output=target,avail,pcent 2>/dev/null || df -BG 2>/dev/null")
    results = []

    for line in stdout.splitlines()[1:]:   # skip header
        parts = line.split()
        if len(parts) < 3:
            continue
        mountpoint = parts[0] if parts[0].startswith('/') else parts[-1]
        # Filter to paths we care about
        if not any(mountpoint == p or mountpoint.startswith(p + '/') for p in LINUX_CHECK_PATHS):
            continue
        try:
            avail_str = parts[1] if parts[0].startswith('/') else parts[3]
            avail_gb  = float(avail_str.replace('G', '').replace('M', ''))
            if 'M' in avail_str:
                avail_gb /= 1024
            pct_used  = parts[2] if parts[0].startswith('/') else parts[4]
        except (ValueError, IndexError):
            continue

        ok = avail_gb >= MIN_FREE_GB
        flag = 'OK' if ok else 'RED'
        status = f"{avail_gb:.1f} GB free ({pct_used} used)"
        print(f"[STEP 6] {'✓' if ok else '🔴'} {mountpoint}: {status} [{flag}]")
        results.append({'path': mountpoint, 'free_gb': round(avail_gb, 1), 'flag': flag, 'detail': status})

    return results


def check_windows_disk(session) -> list[dict]:
    """Use PowerShell Get-PSDrive to check disk space."""
    ps_cmd = "Get-PSDrive -PSProvider FileSystem | Select-Object Name,@{N='FreeGB';E={[math]::Round($_.Free/1GB,2)}},@{N='UsedGB';E={[math]::Round($_.Used/1GB,2)}} | ConvertTo-Csv -NoTypeInformation"
    stdout, stderr, rc = run_winrm_command(session, ps_cmd)
    results = []

    for line in stdout.splitlines()[1:]:
        line = line.strip().strip('"')
        if not line:
            continue
        parts = [p.strip('"') for p in line.split(',')]
        if len(parts) < 3:
            continue
        drive = parts[0] + ':'
        if drive not in WINDOWS_CHECK_DRIVES:
            continue
        try:
            free_gb = float(parts[1])
            used_gb = float(parts[2])
            total   = free_gb + used_gb
            pct     = round(used_gb / total * 100, 1) if total > 0 else 0
        except (ValueError, IndexError):
            continue

        ok   = free_gb >= MIN_FREE_GB
        flag = 'OK' if ok else 'RED'
        detail = f"{free_gb:.1f} GB free ({pct}% used)"
        print(f"[STEP 6] {'✓' if ok else '🔴'} {drive}: {detail} [{flag}]")
        results.append({'path': drive, 'free_gb': round(free_gb, 1), 'flag': flag, 'detail': detail})

    return results


def check_disk(ticket: dict, username: str, **auth_kwargs) -> dict:
    """Check disk space for a ticket's client."""
    hostname = ticket['client']
    os_type  = ticket.get('os_type', 'Linux')

    if os_type == 'Linux':
        conn = ssh_login(hostname, username, **auth_kwargs)
    else:
        conn = winrm_login(hostname, username, auth_method=auth_kwargs.get("winrm_auth","ntlm"), password=auth_kwargs.get("password"))

    if not conn:
        ticket['step6_status'] = 'FAIL'
        ticket['step6_note']   = 'Could not connect for disk check'
        return ticket

    if os_type == 'Linux':
        disk_results = check_linux_disk(conn)
        if hasattr(conn, 'close'):
            conn.close()
    else:
        disk_results = check_windows_disk(conn)

    ticket['step6_disk'] = disk_results

    red_paths = [r for r in disk_results if r['flag'] == 'RED']
    if red_paths:
        details = ', '.join(f"{r['path']} ({r['free_gb']} GB free)" for r in red_paths)
        ticket['step6_status'] = 'RED'
        ticket['step6_note']   = f"🔴 Low disk space on: {details} — manual cleanup required"
        print(f"[STEP 6] 🔴 Low disk space flagged for {hostname}: {details}")
    elif disk_results:
        ticket['step6_status'] = 'PASS'
        ticket['step6_note']   = 'Sufficient disk space on all checked paths'
    else:
        ticket['step6_status'] = 'WARN'
        ticket['step6_note']   = 'No matching mount points found to check'

    return ticket


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Step 6: Disk space check')
    parser.add_argument('--client',   help='Client hostname')
    parser.add_argument('--os',       help='Windows or Linux', default='Linux')
    parser.add_argument('--user',     required=True)
    parser.add_argument('--key',      help='SSH private key')
    parser.add_argument('--password', help='Password')
    parser.add_argument('--min-gb',   type=float, default=MIN_FREE_GB, help='Minimum free GB threshold')
    parser.add_argument('--file',     help='Tickets JSON', default='parsed_tickets.json')
    parser.add_argument('--output',   help='Output JSON',  default='parsed_tickets.json')
    args = parser.parse_args()

    MIN_FREE_GB = args.min_gb  # allow CLI override

    if args.client:
        t = {'ticket_id': 'TEST', 'client': args.client, 'os_type': args.os}
        check_disk(t, args.user, auth_method="password", password=args.password, key_path=args.key)
        print(f"Status: {t['step6_status']} — {t['step6_note']}")
    else:
        with open(args.file) as f:
            tickets = json.load(f)
        for t in tickets:
            if t.get('step5_status') in ('PASS', 'RED'):
                check_disk(t, args.user, auth_method="password", password=args.password, key_path=args.key)
            else:
                t['step6_status'] = 'SKIPPED'
                t['step6_note']   = 'Skipped — previous step failed'
        with open(args.output, 'w') as f:
            json.dump(tickets, f, indent=2)
        print(f"[STEP 6] Saved to {args.output}")
