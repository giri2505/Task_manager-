"""
Step 8: Generate Close Notes
Summarises all actions taken across steps 1–7 into a human-readable close note.
Optionally writes notes back to a CSV (ready for ServiceNow import) or plain text.

Usage: python step8_close_notes.py --file parsed_tickets.json
       python step8_close_notes.py --file parsed_tickets.json --format csv --output close_notes.csv
"""

import argparse
import csv
import json
from datetime import datetime


def build_close_note(ticket: dict) -> str:
    """Build a formatted close note for a single ticket."""
    lines = []
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    lines.append(f"=== Automated Backup Remediation — Close Notes ===")
    lines.append(f"Ticket     : {ticket.get('ticket_id', 'N/A')}")
    lines.append(f"Timestamp  : {now}")
    lines.append(f"NW Server  : {ticket.get('nw_server', 'N/A')}")
    lines.append(f"Client     : {ticket.get('client', 'N/A')}")
    lines.append(f"OS Type    : {ticket.get('os_type', 'N/A')}")
    lines.append("")
    lines.append("--- Step-by-Step Summary ---")

    # Step 1: Parse
    lines.append(f"[Step 1] Parse Ticket     : PASS — Extracted server and client from ticket")

    # Step 2: Reachability
    reach = ticket.get('step2_status', 'N/A')
    note2 = ticket.get('step2_note', '')
    lines.append(f"[Step 2] Reachability     : {reach}" + (f" — {note2}" if note2 else ""))

    if reach == 'FAIL':
        lines.append("")
        lines.append("⚠ Automation stopped at Step 2: Client was unreachable.")
        lines.append("Action required: Verify host is powered on and network connectivity.")
        lines.append(f"Resolution     : UNRESOLVED")
        return '\n'.join(lines)

    # Step 3: OS
    os_status = ticket.get('step3_status', 'N/A')
    os_note   = ticket.get('step3_note', '')
    lines.append(f"[Step 3] OS Identified    : {os_status}" + (f" — {os_note}" if os_note else ""))

    # Step 4: Login
    login_status = ticket.get('step4_status', 'N/A')
    login_note   = ticket.get('step4_note', '')
    lines.append(f"[Step 4] Login            : {login_status}" + (f" — {login_note}" if login_note else ""))

    if login_status == 'FAIL':
        lines.append("")
        lines.append("⚠ Automation stopped at Step 4: Login failed.")
        lines.append("Action required: Verify service account credentials and access.")
        lines.append(f"Resolution     : UNRESOLVED")
        return '\n'.join(lines)

    # Step 5: Services
    svc_status = ticket.get('step5_status', 'N/A')
    svc_note   = ticket.get('step5_note', '')
    svc_list   = ticket.get('step5_services', [])
    lines.append(f"[Step 5] Services         : {svc_status}" + (f" — {svc_note}" if svc_note else ""))
    for svc in svc_list:
        action_str = {'none': '✓ Running', 'restarted': '↺ Restarted', 'restart_failed': '✗ Restart failed', 'skipped': '— Not found'}.get(svc['action'], svc['action'])
        lines.append(f"           {svc['service']:<40} {action_str}")

    # Step 6: Disk
    disk_status = ticket.get('step6_status', 'N/A')
    disk_note   = ticket.get('step6_note', '')
    disk_list   = ticket.get('step6_disk', [])
    lines.append(f"[Step 6] Disk Space       : {disk_status}" + (f" — {disk_note}" if disk_note else ""))
    for d in disk_list:
        flag_icon = '🔴' if d['flag'] == 'RED' else '✓'
        lines.append(f"           {d['path']:<30} {flag_icon} {d['detail']}")

    # Step 7: Retrigger
    retrig_status = ticket.get('step7_status', 'N/A')
    retrig_note   = ticket.get('step7_note', '')
    retrig_cmd    = ticket.get('step7_command', '')
    retrig_out    = ticket.get('step7_output', '')
    lines.append(f"[Step 7] Backup Retrigger : {retrig_status}" + (f" — {retrig_note}" if retrig_note else ""))
    if retrig_cmd:
        lines.append(f"           Command: {retrig_cmd}")
    if retrig_out:
        lines.append(f"           Output : {retrig_out[:200]}")

    lines.append("")

    # Overall resolution
    disk_flag  = ticket.get('step6_status') == 'RED'
    retrig_ok  = ticket.get('step7_status') == 'PASS'
    svc_ok     = ticket.get('step5_status') in ('PASS',)

    if retrig_ok and svc_ok and not disk_flag:
        lines.append("✅ Resolution : RESOLVED — Backup retriggered successfully.")
    elif retrig_ok and disk_flag:
        lines.append("⚠  Resolution : PARTIALLY RESOLVED — Backup retriggered but disk space is low.")
        lines.append("   Action required: Clean up disk space on flagged paths.")
    elif not retrig_ok:
        lines.append("✗  Resolution : UNRESOLVED — Backup retrigger failed. Manual intervention required.")
    else:
        lines.append("⚠  Resolution : REVIEW NEEDED — Check individual step results above.")

    return '\n'.join(lines)


def generate_close_notes(tickets: list[dict], output_format: str = 'text', output_file: str = None):
    """Generate and optionally save close notes for all tickets."""
    results = []

    for t in tickets:
        note = build_close_note(t)
        t['close_notes'] = note
        results.append(t)

        print("\n" + "="*60)
        print(note)

    if output_format == 'csv' and output_file:
        with open(output_file, 'w', newline='', encoding='utf-8') as f:
            fieldnames = ['ticket_id', 'nw_server', 'client', 'os_type',
                          'step2_status', 'step3_status', 'step4_status',
                          'step5_status', 'step5_note', 'step6_status', 'step6_note',
                          'step7_status', 'step7_note', 'close_notes']
            writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction='ignore')
            writer.writeheader()
            writer.writerows(results)
        print(f"\n[STEP 8] Close notes CSV saved to {output_file}")

    elif output_format == 'text' and output_file:
        with open(output_file, 'w', encoding='utf-8') as f:
            for t in results:
                f.write(t['close_notes'] + '\n\n' + '-'*60 + '\n\n')
        print(f"\n[STEP 8] Close notes saved to {output_file}")

    return results


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Step 8: Generate close notes')
    parser.add_argument('--file',   required=True, help='Final tickets JSON')
    parser.add_argument('--format', choices=['text', 'csv', 'json'], default='text')
    parser.add_argument('--output', help='Output file (optional, prints to console if not set)')
    args = parser.parse_args()

    with open(args.file) as f:
        tickets = json.load(f)

    generate_close_notes(tickets, output_format=args.format, output_file=args.output)

    # Save updated JSON with close notes embedded
    with open(args.file, 'w') as f:
        json.dump(tickets, f, indent=2)
