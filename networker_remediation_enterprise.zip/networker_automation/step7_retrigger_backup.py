"""
Step 7: Retrigger Backup on NetWorker Server
Connects to the NetWorker server and retriggers the backup for the failed client.
Command: nsrinfo / saveset / nsrim — update RETRIGGER_CMD once confirmed.

Usage: python step7_retrigger_backup.py --nw-server nw-prod-01 --client app-srv-42 --user svc_backup --key ~/.ssh/id_rsa
       python step7_retrigger_backup.py --file parsed_tickets.json --user svc_backup --key ~/.ssh/id_rsa

Dependencies: pip install paramiko
"""

import argparse
import json
import time
from step4_login import ssh_login, run_ssh_command


# ── UPDATE THIS once the NetWorker retrigger command is confirmed ──────────
# Example commands (uncomment the correct one):
#
# Option A: nsrinfo to verify client + saveset
#   RETRIGGER_CMD = "nsrinfo -s {nw_server} -c {client}"
#
# Option B: saveset retrigger via nsrim
#   RETRIGGER_CMD = "nsrim -S {saveset_id}"
#
# Option C: manual savefs (full backup trigger)
#   RETRIGGER_CMD = "savefs -s {nw_server} -c {client} -g Default /"
#
# Option D: savepnpc for policy-based backup
#   RETRIGGER_CMD = "savepnpc -s {nw_server} -c {client}"
#
# PLACEHOLDER — replace with actual command:
RETRIGGER_CMD = "nsrinfo -s {nw_server} -c {client} -v"

# NetWorker server OS (almost always Linux)
NW_SERVER_OS = 'Linux'
# ───────────────────────────────────────────────────────────────────────────


def retrigger_backup(ticket: dict, username: str, dry_run: bool = False, **auth_kwargs) -> dict:
    """
    SSH into the NetWorker server and run the retrigger command for the failed client.
    """
    nw_server = ticket['nw_server']
    client    = ticket['client']

    # Build the command
    cmd = RETRIGGER_CMD.format(nw_server=nw_server, client=client)

    print(f"[STEP 7] Connecting to NetWorker server: {nw_server}")
    conn = ssh_login(nw_server, username, **auth_kwargs)

    if not conn:
        ticket['step7_status'] = 'FAIL'
        ticket['step7_note']   = f"Could not SSH into NetWorker server {nw_server}"
        return ticket

    if dry_run:
        print(f"[STEP 7] DRY RUN — would run: {cmd}")
        ticket['step7_status'] = 'DRY_RUN'
        ticket['step7_note']   = f"Dry run: would execute: {cmd}"
        conn.close()
        return ticket

    print(f"[STEP 7] Running: {cmd}")
    start = time.time()
    stdout, stderr, rc = run_ssh_command(conn, cmd)
    elapsed = round(time.time() - start, 1)
    conn.close()

    print(f"[STEP 7] Exit code: {rc} (took {elapsed}s)")
    if stdout:
        print(f"[STEP 7] stdout:\n{stdout[:1000]}")
    if stderr:
        print(f"[STEP 7] stderr:\n{stderr[:500]}")

    if rc == 0:
        ticket['step7_status']  = 'PASS'
        ticket['step7_note']    = f"Backup retriggered successfully on {nw_server} for client {client}"
        ticket['step7_command'] = cmd
        ticket['step7_output']  = stdout[:500]
        print(f"[STEP 7] ✓ Backup retriggered for {client} on {nw_server}")
    else:
        ticket['step7_status']  = 'FAIL'
        ticket['step7_note']    = f"Retrigger command failed (exit {rc}): {stderr[:200] or stdout[:200]}"
        ticket['step7_command'] = cmd
        ticket['step7_output']  = stderr[:500] or stdout[:500]
        print(f"[STEP 7] ✗ Retrigger failed for {client}")

    return ticket


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Step 7: Retrigger backup on NetWorker')
    parser.add_argument('--nw-server', help='NetWorker server hostname')
    parser.add_argument('--client',    help='Backup client hostname')
    parser.add_argument('--user',      required=True, help='Service account username')
    parser.add_argument('--key',       help='SSH private key path')
    parser.add_argument('--password',  help='Password')
    parser.add_argument('--dry-run',   action='store_true', help='Print command without running')
    parser.add_argument('--file',      help='Tickets JSON', default='parsed_tickets.json')
    parser.add_argument('--output',    help='Output JSON',  default='parsed_tickets.json')
    args = parser.parse_args()

    if args.nw_server and args.client:
        t = {'ticket_id': 'TEST', 'nw_server': args.nw_server, 'client': args.client}
        retrigger_backup(t, args.user, key_path=args.key, password=args.password, dry_run=args.dry_run)
        print(f"Status: {t['step7_status']} — {t['step7_note']}")
    else:
        with open(args.file) as f:
            tickets = json.load(f)
        for t in tickets:
            prev_ok = t.get('step6_status') in ('PASS', 'RED', 'WARN')
            if t.get('step5_status') == 'PASS' and prev_ok:
                retrigger_backup(t, args.user, key_path=args.key,
                                 password=args.password, dry_run=args.dry_run)
            else:
                t['step7_status'] = 'SKIPPED'
                t['step7_note']   = 'Skipped — previous step did not pass'
        with open(args.output, 'w') as f:
            json.dump(tickets, f, indent=2)
        print(f"[STEP 7] Saved to {args.output}")
