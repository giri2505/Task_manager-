"""
Step 1: Parse Ticket
Reads ServiceNow CSV export and extracts NetWorker server + client name.
Usage: python step1_parse_ticket.py --file tickets.csv
       python step1_parse_ticket.py --ticket INC0098721 --server nw-prod-01 --client app-srv-42
"""

import argparse
import csv
import json
import sys
import os


def parse_from_csv(filepath: str) -> list[dict]:
    """Parse all tickets from a ServiceNow CSV export."""
    tickets = []
    if not os.path.exists(filepath):
        print(f"[ERROR] File not found: {filepath}")
        sys.exit(1)

    with open(filepath, newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            ticket = extract_ticket_fields(row)
            if ticket:
                tickets.append(ticket)

    print(f"[STEP 1] Parsed {len(tickets)} ticket(s) from {filepath}")
    return tickets


def extract_ticket_fields(row: dict) -> dict | None:
    """
    Extract ticket ID, NetWorker server, and client from a CSV row.
    Handles common column name variations from ServiceNow exports.
    """
    # Map common ServiceNow column name variations
    field_map = {
        'ticket_id':  ['number', 'ticket id', 'ticket_id', 'incident', 'inc'],
        'nw_server':  ['networker server', 'nw_server', 'backup server', 'networker_server', 'server'],
        'client':     ['client', 'client name', 'client_name', 'hostname', 'host'],
        'os_type':    ['os', 'os type', 'os_type', 'platform', 'operating system'],
    }

    result = {}
    row_lower = {k.lower().strip(): v for k, v in row.items()}

    for field, aliases in field_map.items():
        for alias in aliases:
            if alias in row_lower and row_lower[alias].strip():
                result[field] = row_lower[alias].strip()
                break
        if field not in result:
            result[field] = None

    # Ticket ID and server are mandatory
    if not result['ticket_id'] or not result['nw_server']:
        print(f"[WARN] Skipping row — missing ticket ID or NetWorker server: {row}")
        return None

    # Default client to server name if missing (edge case)
    if not result['client']:
        print(f"[WARN] {result['ticket_id']}: No client found in ticket, skipping.")
        return None

    # Normalize OS type
    os_raw = (result.get('os_type') or '').lower()
    if 'win' in os_raw:
        result['os_type'] = 'Windows'
    elif 'lin' in os_raw or 'unix' in os_raw:
        result['os_type'] = 'Linux'
    else:
        result['os_type'] = 'Unknown'  # Will be identified in Step 3

    print(f"[STEP 1] ✓ {result['ticket_id']} | Server: {result['nw_server']} | Client: {result['client']} | OS: {result['os_type']}")
    return result


def parse_single(ticket_id: str, nw_server: str, client: str, os_type: str = 'Unknown') -> dict:
    """Build a single ticket dict from CLI arguments."""
    ticket = {
        'ticket_id': ticket_id,
        'nw_server':  nw_server,
        'client':     client,
        'os_type':    os_type,
    }
    print(f"[STEP 1] ✓ Manual ticket: {ticket}")
    return ticket


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Step 1: Parse ServiceNow ticket(s)')
    parser.add_argument('--file',    help='Path to ServiceNow CSV export')
    parser.add_argument('--ticket',  help='Ticket ID (manual entry)')
    parser.add_argument('--server',  help='NetWorker server hostname (manual entry)')
    parser.add_argument('--client',  help='Client hostname (manual entry)')
    parser.add_argument('--os',      help='OS type: Windows or Linux', default='Unknown')
    parser.add_argument('--output',  help='Save parsed tickets to JSON file', default='parsed_tickets.json')
    args = parser.parse_args()

    if args.file:
        tickets = parse_from_csv(args.file)
    elif args.ticket and args.server and args.client:
        tickets = [parse_single(args.ticket, args.server, args.client, args.os)]
    else:
        parser.print_help()
        sys.exit(1)

    with open(args.output, 'w') as f:
        json.dump(tickets, f, indent=2)
    print(f"[STEP 1] Saved to {args.output}")
