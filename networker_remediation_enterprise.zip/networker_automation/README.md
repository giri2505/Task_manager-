# NetWorker Backup Remediation — Enterprise Automation

## Files

| Script | Purpose |
|---|---|
| `step1_parse_ticket.py` | Parse ServiceNow CSV export → extract server + client |
| `step2_reachability.py` | ICMP ping check — stop if host unreachable |
| `step3_identify_os.py` | Probe ports to detect Windows vs Linux |
| `step4_login.py` | SSH key (Linux) or WinRM (Windows) service account login |
| `step5_service_check.py` | Check + restart required backup services |
| `step6_disk_check.py` | Check disk space — flag RED if below threshold |
| `step7_retrigger_backup.py` | Run NetWorker retrigger command on NW server |
| `step8_close_notes.py` | Generate close notes summary |
| `run_remediation.py` | **CLI orchestrator — runs all 8 steps** |
| `dashboard_api.py` | Flask REST API backend |
| `dashboard.html` | Enterprise web dashboard |
| `ai_analysis.py` | **AI Intelligence Layer (Claude-powered)** |

---

## Quick Start

### 1. Install dependencies
```bash
pip install paramiko pywinrm flask flask-cors
```

### 2. Set Anthropic API key (optional — enables AI features)
```bash
export ANTHROPIC_API_KEY=sk-ant-api03-...
```

### 3. Start the dashboard
```bash
python dashboard_api.py
# Open http://localhost:5050
```

---

## Authentication Setup

### Linux — Service Account SSH Key (recommended)

Create a dedicated service account on the automation server:
```bash
useradd -m -s /bin/bash svc_networker
su - svc_networker
ssh-keygen -t ed25519 -f ~/.ssh/id_ed25519 -N ""
```

Distribute the public key to all managed Linux hosts:
```bash
ssh-copy-id -i ~/.ssh/id_ed25519.pub svc_networker@app-srv-42.corp.com
```

In Settings → SSH Auth Method: **SSH Key File**
Key Path: `/home/svc_networker/.ssh/id_ed25519`

### Windows — PAM / WinRM (RDP service account)

Your PAM-managed RDP service account works directly over WinRM.
One-time setup on each Windows host (or via GPO):
```powershell
winrm quickconfig
winrm set winrm/config/service/auth @{Negotiate="true"}
```

In Settings → WinRM Transport: **NTLM** (or **Kerberos** if running `kinit` first)

---

## AI Intelligence Layer

When `ANTHROPIC_API_KEY` is set (or entered in Settings → AI), the system gains:

| Feature | When | What it does |
|---|---|---|
| **Pre-remediation triage** | Auto, before step 2 | Risk score 1–10, predicted root cause, priority label |
| **Root cause analysis** | Auto, after step 8 | Confirmed root cause, remediation summary, preventive actions |
| **AI close notes** | Auto, after RCA | Natural-language ServiceNow close note paragraph |
| **Manual step recommendations** | When automation fails | Ordered L2 troubleshooting checklist |
| **Batch pattern detection** | On-demand, AI Insights tab | Cross-ticket patterns, systemic risk assessment |

All AI features fail gracefully — if the API key is not set, the pipeline runs exactly as before.

---

## CLI Usage

```bash
# SSH key file (Linux) + WinRM NTLM (Windows)
python run_remediation.py \
    --file tickets_export.csv \
    --user svc_networker \
    --auth-method key_file \
    --key-path ~/.ssh/id_ed25519

# SSH agent (keys pre-loaded via ssh-add)
python run_remediation.py --file tickets.csv --user svc_networker --auth-method agent

# Kerberos SSH (run kinit first)
python run_remediation.py --file tickets.csv --user svc_networker@CORP.COM --auth-method gssapi

# Windows only — WinRM Kerberos
python run_remediation.py --file tickets.csv --user svc@CORP.COM --winrm-auth kerberos

# Dry run
python run_remediation.py --file tickets.csv --user svc_networker --auth-method key_file \
    --key-path ~/.ssh/id_ed25519 --dry-run
```

---

## CSV Format (ServiceNow Export)

| Column | Description |
|---|---|
| `Number` or `Ticket ID` | Ticket identifier (e.g. INC0098721) |
| `NetWorker Server` | NetWorker server hostname |
| `Client` | Backup client hostname |
| `OS` or `Platform` | Windows or Linux (optional — auto-detected) |
| `Description` or `Short Description` | Error description (used by AI triage) |

---

## Output Files

- `remediation_results_<timestamp>.json` — full data per ticket (includes AI fields)
- `close_notes_<timestamp>.csv` — importable back to ServiceNow
- `close_notes_<timestamp>.txt` — human-readable summary
