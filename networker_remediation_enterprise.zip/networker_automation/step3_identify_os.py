"""
Step 3: OS Identification
Identifies if the client is Windows or Linux.
Uses SSH banner (port 22) → Linux, WinRM (port 5985/5986) → Windows.
Falls back to the OS field from the ticket if already set.
Usage: python step3_identify_os.py --client app-srv-42.corp.com
       python step3_identify_os.py --file parsed_tickets.json
"""

import argparse
import json
import socket
import sys


TIMEOUT = 4  # seconds


def check_port(hostname: str, port: int) -> bool:
    """Check if a TCP port is open."""
    try:
        with socket.create_connection((hostname, port), timeout=TIMEOUT):
            return True
    except (socket.timeout, ConnectionRefusedError, OSError):
        return False


def identify_os(hostname: str, hint: str = 'Unknown') -> str:
    """
    Probe the host to determine OS type.
    Returns 'Windows' or 'Linux'.
    """
    # If OS already known from ticket, trust it
    if hint in ('Windows', 'Linux'):
        print(f"[STEP 3] OS for {hostname} already known from ticket: {hint}")
        return hint

    print(f"[STEP 3] Probing {hostname} for OS type...")

    # Check SSH port 22 → Linux
    if check_port(hostname, 22):
        print(f"[STEP 3] ✓ Port 22 (SSH) open on {hostname} → Linux")
        return 'Linux'

    # Check WinRM ports → Windows
    if check_port(hostname, 5985) or check_port(hostname, 5986):
        print(f"[STEP 3] ✓ WinRM port open on {hostname} → Windows")
        return 'Windows'

    # Check RDP port 3389 → Windows fallback
    if check_port(hostname, 3389):
        print(f"[STEP 3] ✓ Port 3389 (RDP) open on {hostname} → Windows (fallback)")
        return 'Windows'

    print(f"[STEP 3] ✗ Could not determine OS for {hostname} — defaulting to Linux")
    return 'Linux'


def identify_tickets(tickets: list[dict]) -> list[dict]:
    """Identify OS for each ticket that passed reachability."""
    for t in tickets:
        if not t.get('reachable', True):
            t['step3_status'] = 'SKIPPED'
            t['step3_note'] = 'Skipped — host unreachable'
            continue

        os_type = identify_os(t['client'], t.get('os_type', 'Unknown'))
        t['os_type'] = os_type
        t['step3_status'] = 'PASS'
        t['step3_note'] = f"Identified as {os_type}"
        print(f"[STEP 3] {t['ticket_id']}: {t['client']} → {os_type}")

    return tickets


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Step 3: OS identification')
    parser.add_argument('--client', help='Single client hostname')
    parser.add_argument('--hint',   help='OS hint from ticket (Windows/Linux)', default='Unknown')
    parser.add_argument('--file',   help='Tickets JSON', default='parsed_tickets.json')
    parser.add_argument('--output', help='Output JSON', default='parsed_tickets.json')
    args = parser.parse_args()

    if args.client:
        os_type = identify_os(args.client, args.hint)
        print(f"Result: {os_type}")
        sys.exit(0)

    with open(args.file) as f:
        tickets = json.load(f)

    tickets = identify_tickets(tickets)

    with open(args.output, 'w') as f:
        json.dump(tickets, f, indent=2)
    print(f"[STEP 3] Updated tickets saved to {args.output}")
