# NetWorker Backup Remediation — Python Automation Scripts

## Files

| Script | Purpose |
|---|---|
| `step1_parse_ticket.py` | Parse ServiceNow CSV export → extract server + client |
| `step2_reachability.py` | ICMP ping check — stop if host unreachable |
| `step3_identify_os.py` | Probe ports to detect Windows vs Linux |
| `step4_login.py` | SSH (Linux) or WinRM (Windows) service account login |
| `step5_service_check.py` | Check + restart required backup services |
| `step6_disk_check.py` | Check disk space — flag RED if below threshold |
| `step7_retrigger_backup.py` | Run NetWorker retrigger command on NW server |
| `step8_close_notes.py` | Generate close notes summary |
| `run_remediation.py` | **Master orchestrator — runs all steps** |

---

## Quick Start

### 1. Install dependencies
```bash
pip install paramiko pywinrm
```

### 2. Run full pipeline on a CSV export
```bash
python run_remediation.py \
    --file tickets_export.csv \
    --user svc_backup \
    --key ~/.ssh/id_rsa
```

### For Windows-only environments (WinRM, password auth):
```bash
python run_remediation.py \
    --file tickets_export.csv \
    --user DOMAIN\svc_backup \
    --password "YourPassword"
```

### Dry run (skips actual backup retrigger):
```bash
python run_remediation.py --file tickets.csv --user svc_backup --key ~/.ssh/id_rsa --dry-run
```

### Manual single ticket:
```bash
python step1_parse_ticket.py --ticket INC0098721 --server nw-prod-01 --client app-srv-42 --os Linux
python step2_reachability.py --client app-srv-42
python step5_service_check.py --client app-srv-42 --os Linux --user svc_backup --key ~/.ssh/id_rsa
```

---

## CSV Format (ServiceNow Export)

The script auto-maps common column name variations. Recommended columns:

| Column name | Description |
|---|---|
| `Number` or `Ticket ID` | Ticket identifier (e.g. INC0098721) |
| `NetWorker Server` | NetWorker server hostname |
| `Client` | Backup client hostname |
| `OS` or `Platform` | Windows or Linux (optional — auto-detected if missing) |

---

## Configuration

### Services to check (Step 5)
Edit `step5_service_check.py`:
```python
LINUX_SERVICES = [
    'nsrexecd',     # ← confirm these
    'nsrd',
]
WINDOWS_SERVICES = [
    'NetWorker Remote Exec Service',  # ← confirm these
]
```

### Backup retrigger command (Step 7)
Edit `step7_retrigger_backup.py`:
```python
RETRIGGER_CMD = "nsrinfo -s {nw_server} -c {client} -v"
# Replace with your confirmed command
```

### Disk space threshold (Step 6)
```python
MIN_FREE_GB = 10.0   # Flag RED if free space below this
```

---

## Output Files

After running, you get:
- `remediation_results_<timestamp>.json` — full data per ticket
- `close_notes_<timestamp>.csv` — importable back to ServiceNow
- `close_notes_<timestamp>.txt` — human-readable summary

---

## Requirements

```
paramiko>=3.0        # SSH for Linux clients
pywinrm>=0.4.3       # WinRM for Windows clients
```
